# Logo Design Brief

**Concept:** A rounded play-button / speech-bubble hybrid shape, suggesting both "video" and "chat."
**Primary color:** Pink (#FF2D6F or similar vibrant pink) to match the app's like-button branding.
**Secondary color:** Black or dark charcoal background, white accents.
**Style:** Modern, minimal, bold — similar visual weight to TikTok/Instagram app icons so it reads clearly at small sizes.
**Suggested elements:**
- A play triangle merged into a chat bubble outline.
- Optional: a small "spark" or "star" accent to suggest live/energy.
**Format needed:** 1024x1024 PNG master file, plus adaptive icon versions for Android (foreground/background layers).

*(A designer or an AI image tool can produce the actual artwork from this brief — describe it as: "minimal pink and black app icon, a play-button merged with a chat bubble, flat modern style, rounded corners, for a video social app.")*

---

# App Description

**Name:** [Your App Name — pick something short, e.g. "Vibby", "ChatReel", "PulseLive"]

**Tagline:** Watch, chat, and go live — all in one place.

**Short description:**
A video-first social app where you can scroll short videos, chat with friends, and go live once you build a following. Earn free messages by inviting friends through our referral level system, add music to your videos, and interact with live comments, likes, and shares.

**Key features:**
- Vertical video feed with like, comment, share, and save
- Direct video chat / calling
- Live streaming (unlocked at 500 followers)
- Referral level system: invite friends to earn free messages and level badges (Bronze → Gold Plus)
- In-app music library for videos
- In-app virtual gifts during live streams (spent with in-app coins — not withdrawable)
- Sign up with Email, Phone (OTP), or Google

**Based in:** Lahore, Pakistan
