const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.firestore();

// Stripe secret key is set via: firebase functions:config:set stripe.secret="sk_..."
// NEVER hardcode this key or log it. Card numbers never touch our server —
// the Flutter app collects card details using Stripe's own SDK (flutter_stripe),
// which tokenizes them directly with Stripe. We only ever see a token/PaymentIntent ID.
const stripe = require("stripe")(functions.config().stripe?.secret || "");

/**
 * REFERRAL LEVEL THRESHOLDS
 * Rewards are in-app only: free messages + badge/level name.
 * No cash or crypto payout — keeps this compliant and safe.
 */
const REFERRAL_LEVELS = [
  { count: 10, name: "Bronze", freeMessages: 10 },
  { count: 20, name: "Silver", freeMessages: 25 },
  { count: 50, name: "Diamond", freeMessages: 75 },
  { count: 100, name: "Platinum", freeMessages: 150 },
  { count: 500, name: "Platinum 1", freeMessages: 400 },
  { count: 1000, name: "Platinum 2", freeMessages: 900 },
  { count: 5000, name: "Gold", freeMessages: 5000 },
  { count: 10000, name: "Gold Plus", freeMessages: 12000 },
];

const FREE_MESSAGES_ON_SIGNUP = 10;
const MIN_AGE_YEARS = 13; // matches the "not intended for under 13" line in PRIVACY_POLICY.md

function isValidUsername(username) {
  // 3-20 chars, letters/numbers/underscore, must start with a letter.
  return /^[a-zA-Z][a-zA-Z0-9_]{2,19}$/.test(username || "");
}

function meetsMinimumAge(dateOfBirthIso) {
  const dob = new Date(dateOfBirthIso);
  if (isNaN(dob.getTime())) return false;
  const ageMs = Date.now() - dob.getTime();
  const ageYears = ageMs / (1000 * 60 * 60 * 24 * 365.25);
  return ageYears >= MIN_AGE_YEARS;
}

/**
 * Accepts any country's mobile number in E.164 format: a leading "+",
 * country code, and 8-14 more digits total (e.g. +14155552671 for the US,
 * +923001234567 for Pakistan, +447911123456 for the UK). The frontend's
 * country-code picker always produces numbers in this format, so this is
 * a format check, not a per-country validity check.
 */
function isValidE164Phone(phoneNumber) {
  return /^\+[1-9]\d{7,14}$/.test(phoneNumber || "");
}

/**
 * Usernames must be globally unique. We use a separate /usernames/{username}
 * collection as a "reservation" — claiming one is a transaction that fails
 * if the doc already exists, which is the standard way to get uniqueness
 * out of Firestore (there's no native unique-field constraint).
 */
exports.checkUsernameAvailable = functions.https.onCall(async (data, context) => {
  const { username } = data;
  if (!isValidUsername(username)) {
    return { available: false, reason: "invalid" };
  }
  const doc = await db.collection("usernames").doc(username.toLowerCase()).get();
  return { available: !doc.exists };
});

exports.updateUsername = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const { newUsername } = data;
  if (!isValidUsername(newUsername)) {
    throw new functions.https.HttpsError("invalid-argument", "Username must be 3-20 characters, start with a letter, and contain only letters/numbers/underscore.");
  }
  const usernameKey = newUsername.toLowerCase();

  return db.runTransaction(async (tx) => {
    const newUsernameRef = db.collection("usernames").doc(usernameKey);
    const newUsernameDoc = await tx.get(newUsernameRef);
    if (newUsernameDoc.exists) {
      throw new functions.https.HttpsError("already-exists", "That username is taken.");
    }

    const userRef = db.collection("users").doc(uid);
    const userDoc = await tx.get(userRef);
    const oldUsername = userDoc.data()?.username;

    if (oldUsername) {
      tx.delete(db.collection("usernames").doc(oldUsername.toLowerCase()));
    }
    tx.set(newUsernameRef, { uid });
    tx.update(userRef, { username: newUsername });

    return { success: true };
  });
});

/**
 * Updates the profile's contact phone number (any country, via the
 * frontend's country-code picker). This is a separate field from
 * Firebase Auth's own phone-sign-in/2FA number — it's just what shows on
 * the profile — so it's validated for E.164 format only, not verified
 * by SMS.
 */
exports.updatePhoneNumber = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const { phoneNumber } = data;
  if (phoneNumber !== null && !isValidE164Phone(phoneNumber)) {
    throw new functions.https.HttpsError("invalid-argument", "Enter a valid phone number with country code.");
  }
  await db.collection("users").doc(context.auth.uid).update({ phoneNumber: phoneNumber || null });
  return { success: true };
});

/**
 * Create user profile on sign-up (called from app after Firebase Auth signup)
 */
exports.createUserProfile = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const {
    displayName,
    referredByCode,
    username,
    firstName,
    lastName,
    dateOfBirth, // ISO date string, e.g. "2001-05-14"
    phoneNumber,
  } = data;

  const userRef = db.collection("users").doc(uid);
  const existing = await userRef.get();
  if (existing.exists) {
    return { success: true, message: "Profile already exists." };
  }

  if (!isValidUsername(username)) {
    throw new functions.https.HttpsError("invalid-argument", "Username must be 3-20 characters, start with a letter, and contain only letters/numbers/underscore.");
  }
  if (!dateOfBirth || !meetsMinimumAge(dateOfBirth)) {
    throw new functions.https.HttpsError("invalid-argument", `You must be at least ${MIN_AGE_YEARS} to sign up.`);
  }
  if (phoneNumber && !isValidE164Phone(phoneNumber)) {
    throw new functions.https.HttpsError("invalid-argument", "Enter a valid phone number with country code.");
  }

  const myReferralCode = uid.substring(0, 8).toUpperCase();
  const usernameKey = username.toLowerCase();

  await db.runTransaction(async (tx) => {
    const usernameRef = db.collection("usernames").doc(usernameKey);
    const usernameDoc = await tx.get(usernameRef);
    if (usernameDoc.exists) {
      throw new functions.https.HttpsError("already-exists", "That username is taken.");
    }

    tx.set(usernameRef, { uid });
    tx.set(userRef, {
      displayName: displayName || `${firstName || ""} ${lastName || ""}`.trim() || "New User",
      username,
      firstName: firstName || "",
      lastName: lastName || "",
      dateOfBirth: dateOfBirth || null,
      phoneNumber: phoneNumber || null,
      twoStepEnabled: false,
      referralCode: myReferralCode,
      referredByCode: referredByCode || null,
      referralCount: 0,
      level: "None",
      freeMessagesRemaining: FREE_MESSAGES_ON_SIGNUP,
      followers: 0,
      liveEnabled: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });

  // Credit the referrer, if a valid code was provided
  if (referredByCode) {
    const referrerQuery = await db
      .collection("users")
      .where("referralCode", "==", referredByCode)
      .limit(1)
      .get();

    if (!referrerQuery.empty) {
      const referrerDoc = referrerQuery.docs[0];
      await applyReferralCredit(referrerDoc.id);
    }
  }

  return { success: true, referralCode: myReferralCode };
});

/**
 * Increments referral count for a user and upgrades their level + free
 * messages if a new threshold has been reached.
 */
async function applyReferralCredit(referrerUid) {
  const referrerRef = db.collection("users").doc(referrerUid);

  await db.runTransaction(async (tx) => {
    const doc = await tx.get(referrerRef);
    if (!doc.exists) return;

    const currentData = doc.data();
    const newCount = (currentData.referralCount || 0) + 1;

    let newLevel = currentData.level || "None";
    let bonusMessages = 0;

    for (const tier of REFERRAL_LEVELS) {
      if (newCount === tier.count) {
        newLevel = tier.name;
        bonusMessages = tier.freeMessages;
      }
    }

    tx.update(referrerRef, {
      referralCount: newCount,
      level: newLevel,
      freeMessagesRemaining: admin.firestore.FieldValue.increment(bonusMessages),
    });
  });
}

/**
 * Deduct one free message when user sends a chat message.
 * If no free messages remain, client should prompt for in-app purchase.
 */
exports.consumeFreeMessage = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const userRef = db.collection("users").doc(uid);

  return db.runTransaction(async (tx) => {
    const doc = await tx.get(userRef);
    const remaining = doc.data().freeMessagesRemaining || 0;

    if (remaining <= 0) {
      return { allowed: false, remaining: 0 };
    }

    tx.update(userRef, {
      freeMessagesRemaining: admin.firestore.FieldValue.increment(-1),
    });

    return { allowed: true, remaining: remaining - 1 };
  });
});

/**
 * Enable live-streaming once a user crosses the follower threshold.
 * Call this whenever followers count changes (e.g. from a follow function).
 */
exports.checkLiveEligibility = functions.firestore
  .document("users/{uid}")
  .onUpdate(async (change, context) => {
    const before = change.before.data();
    const after = change.after.data();
    const LIVE_FOLLOWER_THRESHOLD = 500;

    if (
      (after.followers || 0) >= LIVE_FOLLOWER_THRESHOLD &&
      !after.liveEnabled
    ) {
      await change.after.ref.update({ liveEnabled: true });
    }
  });

/**
 * SAVED PAYMENT METHODS (debit/credit card AND bank account)
 *
 * Neither card numbers nor bank account/routing numbers ever reach our
 * server. The Flutter app collects them with Stripe's own SDK
 * (flutter_stripe), which tokenizes everything directly with Stripe. We
 * only ever store a Stripe customer id and payment-method ids.
 */

/**
 * Ensures the signed-in user has a Stripe Customer, creating one if needed,
 * and returns a SetupIntent client secret the app uses to securely collect
 * a new card OR US bank account (ACH) without ever sending details to us.
 */
exports.createSetupIntent = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const userRef = db.collection("users").doc(uid);
  const userDoc = await userRef.get();
  let customerId = userDoc.data()?.stripeCustomerId;

  if (!customerId) {
    const customer = await stripe.customers.create({ metadata: { uid } });
    customerId = customer.id;
    await userRef.update({ stripeCustomerId: customerId });
  }

  // payment_method_types: card for debit/credit cards, us_bank_account for
  // ACH bank transfers. (For bank accounts outside the US, Stripe's
  // equivalents are sepa_debit (EU), bacs_debit (UK), etc. — swap based on
  // your target market.)
  const setupIntent = await stripe.setupIntents.create({
    customer: customerId,
    payment_method_types: ["card", "us_bank_account"],
  });

  return { clientSecret: setupIntent.client_secret, customerId };
});

/**
 * Lists the user's saved payment methods (card + bank account) — only
 * safe, non-sensitive display data (brand, last4) ever comes back to the app.
 */
exports.listPaymentMethods = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const userDoc = await db.collection("users").doc(context.auth.uid).get();
  const customerId = userDoc.data()?.stripeCustomerId;
  if (!customerId) return { cards: [], bankAccounts: [] };

  const [cards, bankAccounts] = await Promise.all([
    stripe.paymentMethods.list({ customer: customerId, type: "card" }),
    stripe.paymentMethods.list({ customer: customerId, type: "us_bank_account" }),
  ]);

  return {
    cards: cards.data.map((pm) => ({
      id: pm.id,
      brand: pm.card.brand,
      last4: pm.card.last4,
    })),
    bankAccounts: bankAccounts.data.map((pm) => ({
      id: pm.id,
      bankName: pm.us_bank_account.bank_name,
      last4: pm.us_bank_account.last4,
    })),
  };
});

exports.removePaymentMethod = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const { paymentMethodId } = data;
  await stripe.paymentMethods.detach(paymentMethodId);
  return { success: true };
});

/**
 * COIN PACKAGES
 * Server-defined prices — never trust a price sent from the client,
 * or a user could pay $0.01 and request 1,000,000 coins.
 */
const COIN_PACKAGES = {
  small: { coins: 100, amountCents: 199, currency: "usd" },   // $1.99
  medium: { coins: 550, amountCents: 999, currency: "usd" },  // $9.99
  large: { coins: 1200, amountCents: 1999, currency: "usd" }, // $19.99
};

/**
 * STEP 1: Create a Stripe PaymentIntent for a chosen coin package.
 * The client uses the returned clientSecret with flutter_stripe's card
 * form to collect and confirm payment. We never see the raw card number —
 * Stripe's SDK sends it directly to Stripe over TLS.
 */
exports.createPaymentIntent = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const { packageId } = data;
  const pkg = COIN_PACKAGES[packageId];
  if (!pkg) {
    throw new functions.https.HttpsError("invalid-argument", "Unknown coin package.");
  }

  const paymentIntent = await stripe.paymentIntents.create({
    amount: pkg.amountCents,
    currency: pkg.currency,
    metadata: { uid: context.auth.uid, packageId, coins: pkg.coins },
    // automatic_payment_methods lets Stripe show card fields (and others,
    // e.g. Apple/Google Pay) without extra config.
    automatic_payment_methods: { enabled: true },
  });

  return { clientSecret: paymentIntent.client_secret };
});

/**
 * STEP 2: Stripe webhook — the source of truth for whether payment actually
 * succeeded. Coins are credited HERE, not when the client says "I paid,"
 * so a tampered client can never grant itself free coins.
 *
 * Configure this URL in your Stripe Dashboard (Developers > Webhooks) and
 * set functions:config:set stripe.webhook_secret="whsec_...".
 */
exports.stripeWebhook = functions.https.onRequest(async (req, res) => {
  const sig = req.headers["stripe-signature"];
  let event;
  try {
    event = stripe.webhooks.constructEvent(
      req.rawBody,
      sig,
      functions.config().stripe?.webhook_secret || ""
    );
  } catch (err) {
    console.error("Webhook signature verification failed.", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === "payment_intent.succeeded") {
    const intent = event.data.object;
    const { uid, coins, kind, boostId } = intent.metadata;

    if (kind === "boost" && boostId) {
      await db.collection("boostRequests").doc(boostId).update({ status: "pending" });
    } else if (uid && coins) {
      await db.collection("users").doc(uid).update({
        coinBalance: admin.firestore.FieldValue.increment(parseInt(coins, 10)),
      });
      await db.collection("users").doc(uid).collection("transactions").add({
        type: "purchase",
        coins: parseInt(coins, 10),
        amountCents: intent.amount,
        currency: intent.currency,
        stripePaymentIntentId: intent.id,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }
  }

  if (event.type === "payment_intent.payment_failed") {
    const intent = event.data.object;
    const { boostId } = intent.metadata;
    if (boostId) {
      await db.collection("boostRequests").doc(boostId).update({ status: "failed" });
    }
  }

  res.json({ received: true });
});

/**
 * VIDEO BOOST (promote a video via Google Ads / Facebook Ads)
 *
 * Real ad-platform integration requires your own verified Google Ads and
 * Meta (Facebook) Business/Ad accounts, OAuth credentials, and agreeing to
 * each platform's ad policies — that setup can't be done inside this
 * starter project. This function does the parts that ARE safe to ship
 * now: validates the request, charges in-app coins, and records the
 * boost request. Where the actual ad-campaign API call belongs is marked
 * with TODOs below.
 */
const BOOST_PACKAGES = {
  small: { coins: 200, priceCents: 499, label: '3-day boost, ~5k extra views' },
  medium: { coins: 500, priceCents: 1499, label: '7-day boost, ~15k extra views' },
  large: { coins: 1000, priceCents: 2999, label: '14-day boost, ~40k extra views' },
};

exports.requestVideoBoost = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const { videoId, platform, packageId, paymentMethodId } = data;
  // paymentMethodId is optional: if provided (a saved card or bank account
  // id from listPaymentMethods), we charge that directly instead of coins.

  if (!["google", "facebook"].includes(platform)) {
    throw new functions.https.HttpsError("invalid-argument", "Unsupported platform.");
  }
  const pkg = BOOST_PACKAGES[packageId];
  if (!pkg) {
    throw new functions.https.HttpsError("invalid-argument", "Unknown boost package.");
  }

  const videoRef = db.collection("videos").doc(videoId);
  const videoDoc = await videoRef.get();
  if (!videoDoc.exists || videoDoc.data().ownerId !== uid) {
    throw new functions.https.HttpsError("permission-denied", "You can only boost your own videos.");
  }

  const userRef = db.collection("users").doc(uid);
  const boostRef = db.collection("boostRequests").doc();

  if (paymentMethodId) {
    // Direct charge to a saved card or bank account. Bank account (ACH)
    // charges are NOT instant — Stripe confirms them asynchronously, so
    // the boost starts as "processing_payment" until the webhook fires.
    const userDoc = await userRef.get();
    const customerId = userDoc.data()?.stripeCustomerId;
    if (!customerId) {
      throw new functions.https.HttpsError("failed-precondition", "No saved payment method found.");
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: pkg.priceCents,
      currency: "usd",
      customer: customerId,
      payment_method: paymentMethodId,
      off_session: true,
      confirm: true,
      metadata: { uid, videoId, boostId: boostRef.id, kind: "boost" },
    });

    await boostRef.set({
      videoId,
      ownerId: uid,
      platform,
      packageId,
      paidWith: "payment_method",
      stripePaymentIntentId: paymentIntent.id,
      status: paymentIntent.status === "succeeded" ? "pending" : "processing_payment",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return { success: true, boostId: boostRef.id, paymentStatus: paymentIntent.status };
  }

  // Fallback: pay with in-app coins (existing behavior).
  await db.runTransaction(async (tx) => {
    const userDoc = await tx.get(userRef);
    const balance = userDoc.data().coinBalance || 0;
    if (balance < pkg.coins) {
      throw new functions.https.HttpsError("failed-precondition", "Not enough coins for this boost package.");
    }
    tx.update(userRef, { coinBalance: admin.firestore.FieldValue.increment(-pkg.coins) });
    tx.set(boostRef, {
      videoId,
      ownerId: uid,
      platform,
      packageId,
      paidWith: "coins",
      coinsSpent: pkg.coins,
      status: "pending",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });

  // TODO: Kick off the real campaign here (e.g. via a Pub/Sub-triggered
  // function, to keep this callable fast):
  //   - platform === 'facebook': call Meta Marketing API
  //     (POST /act_{ad_account_id}/campaigns) using a stored long-lived
  //     Page/Business access token.
  //   - platform === 'google': call Google Ads API
  //     (CampaignService.MutateCampaigns) using OAuth2 credentials tied
  //     to your Google Ads manager account.
  //   Update boostRequests/{id}.status once the platform confirms.

  return { success: true, boostId: boostRef.id };
});

/**
 * CREATOR MONETIZATION
 *
 * Deliberately lower bar than Facebook's in-stream ads program (which
 * requires ~10k followers + 600k watch-minutes in 60 days). Here:
 *   - 100 followers, AND
 *   - 1,000 total views across public videos/posts
 * Payout uses Stripe Connect Express accounts — Stripe handles identity
 * verification (KYC) and the actual bank transfer, so we never need to
 * verify identities or move money ourselves.
 */
const MONETIZATION_MIN_FOLLOWERS = 100;
const MONETIZATION_MIN_VIEWS = 1000;
const EARNINGS_PER_1000_VIEWS_CENTS = 50; // $0.50 / 1000 views

exports.getCreatorStats = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const userDoc = await db.collection("users").doc(uid).get();
  const u = userDoc.data() || {};

  const followers = u.followers || 0;
  const totalViews = u.totalViews || 0;
  const payableViews = totalViews - (u.viewsAlreadyPaid || 0);
  const eligible = followers >= MONETIZATION_MIN_FOLLOWERS && totalViews >= MONETIZATION_MIN_VIEWS;
  const pendingEarningsCents = Math.floor((payableViews / 1000) * EARNINGS_PER_1000_VIEWS_CENTS);

  return {
    followers,
    totalViews,
    eligible,
    minFollowersRequired: MONETIZATION_MIN_FOLLOWERS,
    minViewsRequired: MONETIZATION_MIN_VIEWS,
    pendingEarningsCents,
    payoutAccountReady: !!u.stripeConnectPayoutsEnabled,
  };
});

/**
 * Records a view on a video or post. Called once per playback/impression
 * from the client. Kept as a simple increment — for production, consider
 * debouncing/deduplicating rapid repeat views from the same user.
 */
exports.recordView = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const { contentType, contentId } = data; // contentType: 'video' | 'post'
  const collection = contentType === "post" ? "posts" : "videos";
  const contentRef = db.collection(collection).doc(contentId);
  const contentDoc = await contentRef.get();
  if (!contentDoc.exists) return { success: false };

  await contentRef.update({ views: admin.firestore.FieldValue.increment(1) });
  const ownerField = contentDoc.data().ownerId || contentDoc.data().authorId;
  if (ownerField) {
    await db.collection("users").doc(ownerField)
      .update({ totalViews: admin.firestore.FieldValue.increment(1) });
  }

  return { success: true };
});

/**
 * Creates (or reuses) a Stripe Connect Express account for payouts, and
 * returns an onboarding link. Stripe's own hosted flow collects bank
 * account/debit card + identity details directly — never through our app.
 */
exports.createPayoutOnboardingLink = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const userRef = db.collection("users").doc(uid);
  const userDoc = await userRef.get();
  let accountId = userDoc.data()?.stripeConnectAccountId;

  if (!accountId) {
    const account = await stripe.accounts.create({
      type: "express",
      capabilities: { transfers: { requested: true } },
      metadata: { uid },
    });
    accountId = account.id;
    await userRef.update({ stripeConnectAccountId: accountId });
  }

  const accountLink = await stripe.accountLinks.create({
    account: accountId,
    refresh_url: data.refreshUrl || "https://example.com/reauth",
    return_url: data.returnUrl || "https://example.com/return",
    type: "account_onboarding",
  });

  return { url: accountLink.url };
});

/**
 * Pays out accumulated earnings to the creator's connected bank
 * account/debit card via Stripe Transfer. Only runs if Stripe confirms
 * the connected account can currently receive payouts.
 */
exports.requestPayout = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const userRef = db.collection("users").doc(uid);
  const userDoc = await userRef.get();
  const u = userDoc.data() || {};

  if (!u.stripeConnectAccountId) {
    throw new functions.https.HttpsError("failed-precondition", "No payout account connected yet.");
  }

  const account = await stripe.accounts.retrieve(u.stripeConnectAccountId);
  if (!account.payouts_enabled) {
    throw new functions.https.HttpsError("failed-precondition", "Payout account setup isn't complete yet.");
  }

  const followers = u.followers || 0;
  const totalViews = u.totalViews || 0;
  const payableViews = totalViews - (u.viewsAlreadyPaid || 0);
  const eligible = followers >= MONETIZATION_MIN_FOLLOWERS && totalViews >= MONETIZATION_MIN_VIEWS;
  if (!eligible) {
    throw new functions.https.HttpsError("failed-precondition", "Not yet eligible for monetization.");
  }

  const amountCents = Math.floor((payableViews / 1000) * EARNINGS_PER_1000_VIEWS_CENTS);
  if (amountCents < 100) { // enforce a $1 minimum payout to avoid tiny/fee-losing transfers
    throw new functions.https.HttpsError("failed-precondition", "Minimum payout is $1.00 — keep growing your views.");
  }

  const transfer = await stripe.transfers.create({
    amount: amountCents,
    currency: "usd",
    destination: u.stripeConnectAccountId,
    metadata: { uid },
  });

  await userRef.update({
    viewsAlreadyPaid: totalViews,
    stripeConnectPayoutsEnabled: true,
  });
  await userRef.collection("payouts").add({
    amountCents,
    stripeTransferId: transfer.id,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  return { success: true, amountCents };
});

exports.sendGift = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const senderUid = context.auth.uid;
  const { receiverUid, giftId, coinCost } = data;

  const senderRef = db.collection("users").doc(senderUid);
  const receiverRef = db.collection("users").doc(receiverUid);

  await db.runTransaction(async (tx) => {
    const senderDoc = await tx.get(senderRef);
    const balance = senderDoc.data().coinBalance || 0;
    if (balance < coinCost) {
      throw new functions.https.HttpsError("failed-precondition", "Not enough coins.");
    }
    tx.update(senderRef, { coinBalance: admin.firestore.FieldValue.increment(-coinCost) });
    tx.update(receiverRef, { giftsReceived: admin.firestore.FieldValue.increment(1) });
  });

  return { success: true };
});

/**
 * MOBILE NETWORK PACKAGES (Telenor Pakistan — call/SMS/internet bundles)
 *
 * IMPORTANT: There is no public API for buying Telenor load/bundles as a
 * regular app developer. Real integration requires one of:
 *   - Becoming a Telenor-authorized franchise/reseller (their own B2B API), or
 *   - Going through a licensed aggregator (e.g. a payments company that
 *     already has carrier top-up agreements, similar to how JazzCash/
 *     Easypaisa apps offer "load" as a feature).
 * This function does the safe, generic part — validates the request and
 * charges the user — and clearly marks where the real carrier API call
 * belongs once you have that partnership in place.
 */
const TELENOR_PACKAGES = {
  daily_basic: { label: 'Daily Basic — 300MB + 50 mins', coins: 30 },
  weekly_max: { label: 'Weekly Max — 3GB + 200 mins', coins: 150 },
  monthly_super: { label: 'Monthly Super — 12GB + 1000 mins', coins: 500 },
};

exports.purchaseMobilePackage = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const uid = context.auth.uid;
  const { phoneNumber, packageId } = data;

  const pkg = TELENOR_PACKAGES[packageId];
  if (!pkg) {
    throw new functions.https.HttpsError("invalid-argument", "Unknown package.");
  }
  // Basic Pakistani mobile number sanity check (e.g. 03XXXXXXXXX or +923XXXXXXXXX).
  if (!/^(\+92|0)3\d{9}$/.test(phoneNumber || "")) {
    throw new functions.https.HttpsError("invalid-argument", "Enter a valid Pakistani mobile number.");
  }

  const userRef = db.collection("users").doc(uid);
  const purchaseRef = db.collection("mobileTopups").doc();

  await db.runTransaction(async (tx) => {
    const userDoc = await tx.get(userRef);
    const balance = userDoc.data().coinBalance || 0;
    if (balance < pkg.coins) {
      throw new functions.https.HttpsError("failed-precondition", "Not enough coins for this package.");
    }
    tx.update(userRef, { coinBalance: admin.firestore.FieldValue.increment(-pkg.coins) });
    tx.set(purchaseRef, {
      uid,
      phoneNumber,
      network: "telenor",
      packageId,
      coinsSpent: pkg.coins,
      status: "pending", // pending -> delivered -> failed (updated once real API is wired in)
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });

  // TODO: Call your Telenor reseller/aggregator API here to actually load
  // the bundle onto `phoneNumber`, then update
  // mobileTopups/{purchaseRef.id}.status based on the result. Without
  // that integration, this only records the request — it does not put
  // real minutes/data on anyone's phone yet.

  return { success: true, topupId: purchaseRef.id };
});

/**
 * WHATSAPP-STYLE CHAT
 *
 * Messages are written directly by the client to Firestore (see
 * firestore.rules) for speed — but free-message quota is still enforced
 * server-side via consumeFreeMessage (defined earlier in this file),
 * which the client must call and get `allowed: true` from before writing
 * a text/voice/image/video message.
 */

/**
 * AMAZON — "Login with Amazon" + product browsing
 *
 * There is no way for a third-party app to run Amazon checkout inside
 * itself — Amazon doesn't offer that. What's real and buildable:
 *   1. "Login with Amazon" (LWA) — OAuth sign-in, handled entirely on the
 *      client with Amazon's own SDK; no backend code needed for that part.
 *   2. Product Advertising API (PA API) — search/browse product data and
 *      affiliate links, which open the real Amazon app/site to buy.
 *      Requires your own Amazon Associates account, approved API access,
 *      and (per Amazon's terms) a qualifying sales history to keep
 *      access active. Set credentials via:
 *      firebase functions:config:set amazon.access_key="..." amazon.secret_key="..." amazon.partner_tag="..."
 * This function proxies a PA API search so the access/secret keys never
 * reach the client. It will throw until those config values are set.
 */
exports.searchAmazonProducts = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const { query } = data;
  const cfg = functions.config().amazon || {};
  if (!cfg.access_key || !cfg.secret_key || !cfg.partner_tag) {
    throw new functions.https.HttpsError(
      "failed-precondition",
      "Amazon Product Advertising API isn't configured yet — see the README."
    );
  }

  // TODO: Build and sign the actual PA API v5 request here (AWS
  // Signature v4, using cfg.access_key/cfg.secret_key/cfg.partner_tag)
  // and call https://webservices.amazon.com/paapi5/searchitems.
  // PA API's signing process is involved enough that it's usually done
  // via Amazon's official SDK (paapi5-nodejs-sdk) rather than by hand —
  // install it in this functions folder and call it from here.
  throw new functions.https.HttpsError(
    "unimplemented",
    "PA API signing not wired in yet — see the TODO in searchAmazonProducts."
  );
});

/**
 * LIVE CRICKET
 *
 * Proxies a cricket-scores API so the API key stays server-side. Uses
 * CricAPI (cricapi.com) as the example provider — free tier available,
 * sign up for a key and set it with:
 *   firebase functions:config:set cricket.api_key="..."
 * Swap the fetch URL below for a different provider if you prefer one
 * (e.g. RapidAPI's Cricbuzz, SportRadar) — the calling shape from the
 * client (cricketLiveScores) stays the same either way.
 */
exports.cricketLiveScores = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const apiKey = functions.config().cricket?.api_key;
  if (!apiKey) {
    throw new functions.https.HttpsError(
      "failed-precondition",
      "Cricket API isn't configured yet — see the README."
    );
  }

  const response = await fetch(`https://api.cricapi.com/v1/currentMatches?apikey=${apiKey}&offset=0`);
  if (!response.ok) {
    throw new functions.https.HttpsError("internal", "Could not reach the cricket data provider.");
  }
  const json = await response.json();
  return { matches: json.data || [] };
});

/**
 * NEWS
 *
 * Proxies a news headlines API the same way — key stays server-side.
 * Uses NewsAPI.org as the example provider (free tier for development,
 * paid for production use). Sign up and set the key with:
 *   firebase functions:config:set news.api_key="..."
 */
exports.latestNews = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign in required.");
  }
  const apiKey = functions.config().news?.api_key;
  if (!apiKey) {
    throw new functions.https.HttpsError(
      "failed-precondition",
      "News API isn't configured yet — see the README."
    );
  }
  const country = (data && data.country) || "pk";

  const response = await fetch(
    `https://newsapi.org/v2/top-headlines?country=${country}&apiKey=${apiKey}`
  );
  if (!response.ok) {
    throw new functions.https.HttpsError("internal", "Could not reach the news provider.");
  }
  const json = await response.json();
  return { articles: json.articles || [] };
});


