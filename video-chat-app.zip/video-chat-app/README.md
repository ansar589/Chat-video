# Video Chat App — Starter Project

A starter codebase for a TikTok-style video social app with video chat, live
streaming, and an in-app (non-cash) referral level system.

## New in this update
- **Payment methods (card + bank account)**: `payment_methods_screen.dart`
  lets users save a debit/credit card or a bank account via Stripe's
  hosted setup flow (`createSetupIntent`/`listPaymentMethods`/
  `removePaymentMethod` in `index.js`). Boosting a video now offers
  "Pay with coins" or any saved card/bank account
  (`requestVideoBoost` accepts an optional `paymentMethodId`).
  ⚠️ **Pakistan note:** Stripe does not currently support Pakistan as a
  platform/business country for receiving payouts, and `us_bank_account`
  (ACH) only works for US bank accounts. This code is written against
  Stripe because it's the best-documented option for demoing/shipping
  internationally. For a Lahore-based business taking real payments from
  Pakistani users, swap in **PayFast** (supports JazzCash, Easypaisa, and
  local debit/credit cards) or a similar local gateway — the app's
  `PaymentService` is intentionally a thin wrapper so you can replace the
  Stripe calls without touching the UI.
- **Facebook-style Posts feed**: a second, separate feed
  (`posts_feed_screen.dart`, `create_post_screen.dart`) for text/image
  posts with like, comment, share, and save — alongside (not replacing)
  the short-video feed. Accessible from the new "Posts" tab in the bottom
  nav.
- **Monetization (creator payouts)**: `monetization_screen.dart` shows
  progress toward eligibility and lets creators set up payouts (Stripe
  Connect Express — collects bank account/debit card + identity
  verification through Stripe's own hosted flow) and request a payout.
  Requirements are deliberately much lower than Facebook's in-stream ads
  program (100 followers + 1,000 views here, vs. Facebook's roughly
  10,000 followers + 600,000 watch-minutes/60 days). Earnings are
  currently calculated from view count (`$0.50 / 1,000 views` — tune
  `EARNINGS_PER_1000_VIEWS_CENTS` in `index.js`); wire in `recordView`
  calls from the video/post players to start counting views.

## New in this update
- **Profile picture editor**: tap the avatar (on Profile or in
  `edit_profile_screen.dart`) to pick a photo and crop/rotate it (circular
  crop) before it's uploaded — using `image_cropper`.
- **Bio**: a short text field (150 chars) shown on the profile.
- **Social links**: YouTube, WhatsApp, Facebook, Telegram, Discord — each
  is a plain URL field; tapping the icon on the profile opens it in the
  relevant app/browser via `url_launcher`. These are stored as plain
  strings on the user doc (`socialLinks: { youtube, whatsapp, facebook,
  telegram, discord }`) — no special validation beyond "non-empty," so
  consider adding basic URL-format checks before shipping to production.

## New in this update
- **Namaz (prayer) timings + popup reminders**: `prayer_times_screen.dart`
  fetches daily prayer times from the free [Aladhan
  API](https://aladhan.com/prayer-times-api) (defaults to Lahore,
  Pakistan) and shows them in a list. Reminders fire two ways:
  1. A **system notification** (via `flutter_local_notifications`) scheduled
     for each prayer time — works even if the app is closed/locked
     (`fullScreenIntent: true` makes it appear as a popup).
  2. An **in-app popup dialog** shown if the user happens to have the
     Prayer Times screen open exactly at prayer time.
  Reminders are fetched and scheduled once automatically when the app
  opens (`home_feed_screen.dart`), so they work without visiting the
  screen — toggle them off from a switch on the Namaz Timings screen.
  - **Android**: add to `AndroidManifest.xml`: `POST_NOTIFICATIONS`,
    `SCHEDULE_EXACT_ALARM`, `USE_FULL_SCREEN_INTENT`. On Android 13+ you
    also need to request the notification permission at runtime.
  - **iOS**: notification permission is requested automatically by
    `flutter_local_notifications` on first init.
  - The city/country is currently hardcoded to Lahore, Pakistan
    (matching this app's base location) — pass a different city/country
    to `PrayerTimesService.fetchToday()` to support other users, or wire
    it up to the device's GPS location for auto-detection.

## New in this update
- **WhatsApp-style chat**: `chat_list_screen.dart` + `chat_screen.dart` —
  1-on-1 conversations with text, voice messages (hold the mic button to
  record, release to send), photos, and videos. Voice playback/recording
  use `record` + `just_audio`; media uploads go to Firebase Storage.
  Every message (any type) still goes through the same 10-free /
  referral-earned / paid `consumeFreeMessage` quota check already built
  for the free-message system — sending isn't free just because it's a
  photo instead of text.
- **Telenor mobile packages**: `mobile_packages_screen.dart` lets users
  "buy" Daily/Weekly/Monthly Telenor bundles with coins.
  ⚠️ **Reality check:** there's no public API for loading real
  minutes/data onto a Telenor number as a third-party app. This charges
  the user and records the request (`mobileTopups` collection in
  Firestore) but does **not** actually deliver a bundle — that requires
  becoming a Telenor-authorized reseller/franchise, or partnering with an
  aggregator that already has that relationship (similar to how JazzCash/
  Easypaisa apps offer "load"). The `TODO` in
  `purchaseMobilePackage` (`index.js`) marks exactly where that real API
  call goes once you have such a partnership — don't ship this to real
  users as-is or it'll take their coins without delivering anything.

## New in this update
- **Group chats**: `create_group_screen.dart` (name + search/select
  members by display name), `group_chat_screen.dart` (text, voice, photo,
  video — same message types as 1-on-1 chat, with sender name shown on
  each bubble), `group_info_screen.dart` (member list, admin badge, admin
  can remove members, anyone can leave). Groups live in their own
  `/groups` Firestore collection (separate from 1-on-1 `/chats`), and the
  **security rules do the validation work** here instead of a Cloud
  Function: group creation requires a non-empty name and 3–256
  participants, only admins can change membership/name, and a member can
  only ever remove *themself* from the participant list (see
  `firestore.rules`). The chat list screen (`chat_list_screen.dart`) now
  shows a "Groups" section above "Chats", and a group-add icon in the
  app bar opens group creation.
  - Every group message also goes through the same `consumeFreeMessage`
    quota check as 1-on-1 chat.
  - **Known simplification:** the member picker searches by display name
    prefix — there's no separate "contacts" or "friends" concept yet, so
    you can add any user on the platform to a group, not just people
    you've interacted with. Add a friends/following list first if you
    want to restrict that.

## New in this update
- **Full account fields at sign-up**: `signup_screen.dart` now collects
  first name, last name, a live-checked unique username, email, password,
  date of birth (with a minimum-age check — 13+, matching the privacy
  policy), and an optional phone number. Backend validation
  (`createUserProfile`, `checkUsernameAvailable`, `updateUsername` in
  `index.js`) enforces username format/uniqueness via a `/usernames`
  reservation collection and rejects signups under the minimum age.
- **Forgot password**: `forgot_password_screen.dart`, linked from the
  sign-in screen — sends Firebase's built-in password reset email.
- **Account & Security screen**: change password and change email (both
  require re-entering the current password — Firebase requires recent
  re-authentication for these), plus a **two-step verification** toggle
  implemented as Firebase Auth's phone-based multi-factor authentication
  (enroll a phone number; future sign-ins on a new device also need an
  SMS code). This needs a real device to test — SMS delivery and
  reCAPTCHA don't work in most emulators.
- **Add another account / Switch account**: `switch_account_screen.dart`
  + `account_store.dart` remember the last 5 accounts signed into on
  this device (uid/email/display name only — never a password) and let
  you jump back to one with a tap.
  ⚠️ **Limitation to know about:** this app keeps only **one** Firebase
  Auth session live at a time, so "switching" signs you out of the
  current account and back into the picked one (password/Google/phone
  re-entry required) — it's a quick-pick list, not true simultaneous
  multi-account like Gmail's app. Real simultaneous sessions would need a
  secondary named `FirebaseApp` instance per account and passing a
  specific `FirebaseAuth` instance through every screen instead of the
  default `FirebaseAuth.instance` used throughout this codebase — a
  much bigger structural change than this update makes.

## New in this update
- **Settings screen**: `settings_screen.dart` consolidates Edit Profile,
  Account & Security, Switch/Add Account, Payment Methods, Monetization,
  Namaz Timings, Telenor Packages, and Sign Out into one organized menu
  (gear icon on the Profile screen), instead of a long button stack on
  the profile front. The profile front now only keeps the "Edit Profile"
  button visible directly.
- **Multi-country phone numbers**: `edit_profile_screen.dart` now has a
  phone number field with a country-code picker (`country_code_picker`
  package — search, flags, dial codes for every country), defaulting to
  Pakistan (+92) but not limited to it. The same picker was added to
  `signup_screen.dart`'s phone field and `account_security_screen.dart`'s
  two-step-verification phone field, so every phone input in the app
  works the same way. Numbers are combined into E.164 format
  (`+<countrycode><number>`) before being sent to the backend.
  - Backend: `isValidE164Phone()` in `index.js` validates the format
    (works for any country, not just Pakistan), used in both
    `createUserProfile` and the new `updatePhoneNumber` callable
    function. `firestore.rules` now blocks direct client writes to
    `phoneNumber` on `/users/{userId}` — same pattern as `username` —
    so a client can't bypass validation by writing Firestore directly.
  - This profile `phoneNumber` is separate from Firebase Auth's own
    phone-sign-in/2FA number — it's just contact info shown on the
    profile, not itself SMS-verified.

## New in this update
- **White + pink theme**: switched the entire app from the earlier
  black/dark UI to a **white background with pink text and icons**,
  across all 26 screens (`main.dart`'s `ThemeData.scaffoldBackgroundColor`
  plus every screen's own `Scaffold`/`AppBar` colors). Cards and dialogs
  that were dark grey are now a light pink tint so they stay visible
  against the white page.
  - **Kept intentionally dark**: video/voice-message placeholder boxes in
    chat (`chat_screen.dart`, `group_chat_screen.dart`) and the profile-photo
    cropper's toolbar — video content and photo editors conventionally
    stay dark regardless of the app's own theme (same as TikTok/Instagram).
    Say the word if you'd rather these be light too.
  - Chat bubbles now use a **readable contrast pair**: your own messages
    sit on a dark pink bubble with white text; the other person's sit on
    a pale pink bubble with dark pink text — plain "pink text everywhere"
    would have made your own messages unreadable against their own
    darker-pink bubble.
  - All pink shades are literal hex values (`Color(0xFFEC407A)` etc.,
    matching Material's official pink swatch) rather than
    `Colors.pink[400]`-style lookups — the latter can't be used inside any
    `const` widget in Dart, which the earlier code relied on throughout.

## New in this update
- **Amazon**: `amazon_screen.dart` has a working "Login with Amazon"
  button (opens Amazon's real OAuth page — register a Security Profile at
  developer.amazon.com/loginwithamazon and replace `AMAZON_CLIENT_ID`)
  and a product search box calling `searchAmazonProducts`. That Cloud
  Function is a structured **stub** — Amazon's Product Advertising API
  needs your own Associates account, approved API access, and
  AWS-Signature-v4-signed requests (usually done via Amazon's
  `paapi5-nodejs-sdk` rather than by hand); the TODO in `index.js` marks
  exactly where that goes. **There is no checkout-inside-the-app option**
  — no third-party app can do that; "Shop on Amazon" opens the real
  Amazon app/site, same as every other app handles Amazon purchases.
- **Live Cricket**: `live_cricket_screen.dart` + `cricketLiveScores`
  Cloud Function, wired to CricAPI (cricapi.com, free tier available) as
  the example provider — get a key and set it with
  `firebase functions:config:set cricket.api_key="..."`. Swap the fetch
  URL in `index.js` for a different provider (RapidAPI Cricbuzz,
  SportRadar, etc.) if you prefer one; the app-facing shape doesn't change.
- **News**: `news_screen.dart` + `latestNews` Cloud Function, wired to
  NewsAPI.org (free tier for development) as the example provider — get
  a key and set it with `firebase functions:config:set news.api_key="..."`.
  Tapping an article opens the original source in the browser.
  - All three new Cloud Functions return a clear `failed-precondition`
    error (shown in the app as "isn't set up yet") when their API key
    hasn't been configured, instead of silently failing or showing fake
    data.

## Previously added
- **Video visibility**: Public, Private, or Adult (18+) — set at upload
  time (`video_upload_screen.dart`). The main feed query only shows
  `visibility == 'public'` videos.
  ⚠️ **Heads up:** Google Play and Apple's App Store both prohibit or
  heavily restrict apps that host pornographic/sexually explicit content.
  An "Adult" flag as a *content warning/age-gate* (like marking something
  mature or sensitive) is fine, but if you intend to host actual explicit
  content, plan for a website/direct-APK distribution instead of the app
  stores, and add real age verification (a checkbox alone is weak — many
  platforms use ID checks or third-party age-verification services).
- **Hashtags**: chip-based input at upload, stored as an array on each
  video document (`hashtags: string[]`).
- **Video boost (Google/Facebook)**: `requestVideoBoost` Cloud Function
  validates ownership, charges coins server-side, and logs a
  `boostRequests` record. Actually submitting the ad campaign to Meta's
  Marketing API or Google Ads API requires your own verified ad accounts
  and OAuth credentials — see the TODOs in `index.js`. Without that
  wiring, boost requests are recorded but not yet actually submitted to
  either platform.
- Firestore composite index needed: `videos` collection on
  `visibility (Ascending), createdAt (Descending)` — Firebase will show a
  direct link to create this the first time you run the feed query, or
  add it manually in the Firebase Console under Firestore → Indexes.

## What's included
- `backend/functions/` — Firebase Cloud Functions: user profiles, referral
  level logic, free-message tracking, live-eligibility trigger, **Stripe
  card payments** (PaymentIntent creation + webhook that credits coins
  only after Stripe confirms payment), in-app gifting.
- `backend/firestore/firestore.rules` — Firestore security rules.
- `frontend/` — Flutter app: sign-up/sign-in (email, phone OTP, Google),
  video feed with like/comment/share/save/music buttons, **CapCut-style
  pre-upload video editor (trim + filter presets)**, video upload to
  Firebase Storage, **credit/debit card checkout via Stripe**, live
  streaming screen with grid + live comments, profile screen with referral
  progress and coin balance.
- `PRIVACY_POLICY.md`, `LOGO_AND_DESCRIPTION.md` — supporting docs.

## Card payments — how it stays secure
- The app never collects or stores raw card numbers. `flutter_stripe`'s
  built-in payment sheet talks directly to Stripe; our backend only ever
  sees a `PaymentIntent` id.
- Coin prices are defined **server-side** (`COIN_PACKAGES` in
  `functions/index.js`) — the client can only pick a package id, not set
  its own price.
- Coins are credited only inside `stripeWebhook`, after Stripe confirms
  the charge succeeded — never from a direct client call. This prevents a
  modified app from granting itself free coins.

## What was intentionally left out (and why)
- **Cash/crypto referral payouts and crypto wallet sign-up** — this
  structure (pay users for recruiting more users) resembles a pyramid
  scheme and is legally risky, especially combined with unlicensed crypto
  payouts. Rewards here are in-app only (free messages + level badges).
- **Named copyrighted songs** — replace `sampleLicensedTracks` in
  `music_picker_screen.dart` with tracks you've properly licensed (e.g.
  Epidemic Sound, Artlist, YouTube Audio Library, or original artists who've
  granted rights).
- **"4-person live match" with crypto gifts** — implemented as a live room
  with viewer grid + comments only. If you want a competitive/team format,
  it should stay entertainment-only (no wagering).

## Setup

### Backend (Firebase)
1. Install the Firebase CLI: `npm install -g firebase-tools`
2. `firebase login`
3. `firebase init` in `backend/` (select Functions + Firestore, use existing
   files when prompted)
4. `cd backend/functions && npm install`
5. Create a [Stripe](https://stripe.com) account, then set your keys:
   ```
   firebase functions:config:set stripe.secret="sk_test_..." stripe.webhook_secret="whsec_..."
   ```
6. `firebase deploy --only functions,firestore:rules`
7. In the Stripe Dashboard → Developers → Webhooks, add an endpoint
   pointing to your deployed `stripeWebhook` function URL, listening for
   `payment_intent.succeeded`.

### Frontend (Flutter)
1. Install Flutter: https://docs.flutter.dev/get-started/install
2. `cd frontend && flutter pub get`
3. Run `flutterfire configure` (requires the FlutterFire CLI) to generate
   `firebase_options.dart` and connect this app to your Firebase project.
4. Add your Agora App ID (for video chat/live) in a config file — sign up
   at https://www.agora.io/ (free tier available).
5. Set your Stripe **publishable** key in `lib/main.dart`
   (`Stripe.publishableKey = 'pk_test_...'`). Never put your Stripe
   **secret** key here — that only ever lives in Cloud Functions config.
6. Video editing uses `ffmpeg_kit_flutter` — no extra native setup needed
   on Android; for iOS, ensure `ios/Podfile` platform is set to `:ios, '12.0'`
   or higher.
7. Add camera/microphone/storage permissions:
   - **Android** (`android/app/src/main/AndroidManifest.xml`): `CAMERA`,
     `RECORD_AUDIO`, `READ_MEDIA_VIDEO` (or `READ_EXTERNAL_STORAGE` on
     older SDKs). `RECORD_AUDIO` is also required for chat voice messages.
   - **iOS** (`ios/Runner/Info.plist`): `NSCameraUsageDescription`,
     `NSMicrophoneUsageDescription`, `NSPhotoLibraryUsageDescription`.
8. Replace `assets/logo.png` with your final logo (see
   `LOGO_AND_DESCRIPTION.md` for the design brief).

### Run on a device/emulator
```
flutter run
```

### Build the APK
```
flutter build apk --release
```
The signed APK will be at:
`frontend/build/app/outputs/flutter-apk/app-release.apk`

> Note: for a real release build you'll need to set up a signing key
> (`android/key.properties` + keystore) — see Flutter's official Android
> deployment guide.

## Still to build
- Video playback in the feed itself (wire up `video_player` on
  `VideoCard` to actually play `videoUrl` — currently a placeholder box).
- Agora integration for live 1-on-1 chat and live streaming.
- Additional local payment methods (JazzCash/Easypaisa) alongside Stripe,
  if you want options beyond international cards.
- Push notifications for new followers/gifts/comments.
- Content moderation for uploaded videos and live streams.
- More advanced editing (text overlays, stickers, speed control) — the
  `video_editor` package supports cropping/rotation too if you want to
  extend the editor screen.
