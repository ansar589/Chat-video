import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/user_model.dart';
import 'buy_coins_screen.dart';
import 'edit_profile_screen.dart';
import 'settings_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const SizedBox();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Profile'),
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: CircularProgressIndicator());
          }
          final user = AppUser.fromMap(uid, snapshot.data!.data() as Map<String, dynamic>);
          final nextLevel = _nextLevel(user.referralCount);

          return Padding(
            padding: const EdgeInsets.all(20.0),
            child: ListView(
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: IconButton(
                    icon: const Icon(Icons.settings, color: const Color(0xFFD81B60)),
                    onPressed: () => Navigator.push(
                        context, MaterialPageRoute(builder: (_) => SettingsScreen(user: user))),
                  ),
                ),
                Center(
                  child: CircleAvatar(
                    radius: 45,
                    backgroundColor: const Color(0xFFC2185B),
                    backgroundImage: user.photoUrl != null ? NetworkImage(user.photoUrl!) : null,
                    child: user.photoUrl == null
                        ? const Icon(Icons.person, size: 40, color: Colors.white)
                        : null,
                  ),
                ),
                const SizedBox(height: 12),
                Center(
                  child: Text(user.displayName, style: const TextStyle(color: Colors.pink, fontSize: 22)),
                ),
                const SizedBox(height: 4),
                Center(
                  child: Text('Referral Code: ${user.referralCode}',
                      style: const TextStyle(color: const Color(0xFFEC407A))),
                ),
                if (user.bio.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Text(user.bio, textAlign: TextAlign.center,
                      style: const TextStyle(color: const Color(0xFFD81B60))),
                ],
                if (user.socialLinks.values.any((v) => v.isNotEmpty)) ...[
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _socialIcon(Icons.play_circle_fill, user.socialLinks['youtube']),
                      _socialIcon(Icons.chat, user.socialLinks['whatsapp']),
                      _socialIcon(Icons.facebook, user.socialLinks['facebook']),
                      _socialIcon(Icons.send, user.socialLinks['telegram']),
                      _socialIcon(Icons.discord, user.socialLinks['discord']),
                    ],
                  ),
                ],
                const SizedBox(height: 8),
                Center(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.edit, color: Colors.pink, size: 16),
                    label: const Text('Edit Profile', style: TextStyle(color: Colors.pink)),
                    onPressed: () => Navigator.push(
                        context, MaterialPageRoute(builder: (_) => EditProfileScreen(user: user))),
                  ),
                ),
                const SizedBox(height: 20),
                _statCard('Current Level', user.level),
                _statCard('Total Referrals', '${user.referralCount}'),
                _statCard('Free Messages Left', '${user.freeMessagesRemaining}'),
                _statCard('Followers', '${user.followers}'),
                _statCard('Live Streaming', user.liveEnabled ? 'Unlocked' : 'Locked (need 500 followers)'),
                _statCard('Coin Balance', '${user.coinBalance}'),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                  icon: const Icon(Icons.credit_card),
                  label: const Text('Buy Coins (Card)'),
                  onPressed: () => Navigator.push(
                      context, MaterialPageRoute(builder: (_) => const BuyCoinsScreen())),
                ),
                const SizedBox(height: 20),
                if (nextLevel != null) ...[
                  Text(
                    'Next level: ${nextLevel['name']} at ${nextLevel['count']} referrals',
                    style: const TextStyle(color: Colors.pinkAccent),
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: user.referralCount / nextLevel['count'],
                    backgroundColor: const Color(0xFFF8BBD0),
                    color: Colors.pink,
                  ),
                ] else
                  const Text('Max level reached!', style: TextStyle(color: Colors.pinkAccent)),
              ],
            ),
          );
        },
      ),
    );
  }

  Map<String, dynamic>? _nextLevel(int referralCount) {
    for (final tier in AppUser.levelThresholds) {
      if (referralCount < tier['count']) return tier;
    }
    return null;
  }

  Widget _statCard(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: const Color(0xFFEC407A))),
          Text(value, style: const TextStyle(color: Colors.pink, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _socialIcon(IconData icon, String? url) {
    if (url == null || url.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: IconButton(
        icon: Icon(icon, color: const Color(0xFFD81B60)),
        onPressed: () async {
          final uri = Uri.tryParse(url);
          if (uri != null) {
            await launchUrl(uri, mode: LaunchMode.externalApplication);
          }
        },
      ),
    );
  }
}
