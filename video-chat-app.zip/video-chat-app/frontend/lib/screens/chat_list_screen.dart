import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'chat_screen.dart';
import 'group_chat_screen.dart';
import 'create_group_screen.dart';

/// Deterministic chat id so both participants always land on the same
/// conversation document, regardless of who started it.
String chatIdFor(String uidA, String uidB) {
  final sorted = [uidA, uidB]..sort();
  return '${sorted[0]}_${sorted[1]}';
}

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final myUid = FirebaseAuth.instance.currentUser?.uid;
    if (myUid == null) return const SizedBox();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Chats'),
        actions: [
          IconButton(
            icon: const Icon(Icons.group_add),
            tooltip: 'New group',
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const CreateGroupScreen())),
          ),
        ],
      ),
      body: ListView(
        children: [
          _GroupsSection(myUid: myUid),
          const Divider(color: const Color(0xFFF48FB1), height: 1),
          _DirectChatsSection(myUid: myUid),
        ],
      ),
    );
  }
}

class _GroupsSection extends StatelessWidget {
  final String myUid;
  const _GroupsSection({required this.myUid});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('groups')
          .where('participants', arrayContains: myUid)
          .orderBy('lastMessageAt', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const SizedBox();
        final docs = snapshot.data!.docs;
        if (docs.isEmpty) return const SizedBox();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Text('Groups', style: TextStyle(color: const Color(0xFFEC407A), fontSize: 12, fontWeight: FontWeight.bold)),
            ),
            ...docs.map((doc) {
              final data = doc.data() as Map<String, dynamic>;
              final name = data['name'] ?? 'Group';
              final lastMessage = data['lastMessage'] ?? '';
              final lastType = data['lastMessageType'] ?? 'text';
              return ListTile(
                leading: CircleAvatar(backgroundColor: const Color(0xFFC2185B), child: const Icon(Icons.group, color: Colors.white)),
                title: Text(name, style: const TextStyle(color: Colors.pink)),
                subtitle: Text(
                  lastType == 'text' ? lastMessage : _previewForType(lastType),
                  style: const TextStyle(color: const Color(0xFFEC407A)),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => GroupChatScreen(groupId: doc.id, groupName: name)),
                ),
              );
            }),
          ],
        );
      },
    );
  }
}

class _DirectChatsSection extends StatelessWidget {
  final String myUid;
  const _DirectChatsSection({required this.myUid});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('chats')
          .where('participants', arrayContains: myUid)
          .orderBy('lastMessageAt', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final docs = snapshot.data!.docs;
        if (docs.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: Text('No conversations yet', style: TextStyle(color: const Color(0xFFEC407A)))),
          );
        }
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Text('Chats', style: TextStyle(color: const Color(0xFFEC407A), fontSize: 12, fontWeight: FontWeight.bold)),
            ),
            ...docs.map((doc) {
              final data = doc.data() as Map<String, dynamic>;
              final participants = List<String>.from(data['participants'] ?? []);
              final otherUid = participants.firstWhere((u) => u != myUid, orElse: () => '');
              final names = Map<String, dynamic>.from(data['participantNames'] ?? {});
              final otherName = names[otherUid] ?? 'User';
              final lastMessage = data['lastMessage'] ?? '';
              final lastType = data['lastMessageType'] ?? 'text';

              return ListTile(
                leading: CircleAvatar(backgroundColor: const Color(0xFFC2185B), child: const Icon(Icons.person, color: Colors.white)),
                title: Text(otherName, style: const TextStyle(color: Colors.pink)),
                subtitle: Text(
                  lastType == 'text' ? lastMessage : _previewForType(lastType),
                  style: const TextStyle(color: const Color(0xFFEC407A)),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChatScreen(
                      chatId: doc.id,
                      otherUid: otherUid,
                      otherName: otherName,
                    ),
                  ),
                ),
              );
            }),
          ],
        );
      },
    );
  }
}

String _previewForType(String type) {
  switch (type) {
    case 'voice':
      return 'Voice message';
    case 'image':
      return 'Photo';
    case 'video':
      return 'Video';
    default:
      return '';
  }
}
