import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'create_post_screen.dart';

/// Facebook-style feed: text/image posts users can like, comment on,
/// share, and save — separate from the short-video feed.
class PostsFeedScreen extends StatelessWidget {
  const PostsFeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Posts'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_box_outlined),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const CreatePostScreen())),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('posts')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(
                child: Text('No posts yet — be the first to share something!',
                    style: TextStyle(color: const Color(0xFFEC407A))));
          }
          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 8),
            itemCount: docs.length,
            itemBuilder: (context, i) =>
                PostCard(postId: docs[i].id, data: docs[i].data() as Map<String, dynamic>),
          );
        },
      ),
    );
  }
}

class PostCard extends StatefulWidget {
  final String postId;
  final Map<String, dynamic> data;
  const PostCard({super.key, required this.postId, required this.data});

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  bool _liked = false;
  bool _saved = false;

  Future<void> _toggleLike() async {
    setState(() => _liked = !_liked);
    await FirebaseFirestore.instance.collection('posts').doc(widget.postId).update({
      'likes': FieldValue.increment(_liked ? 1 : -1),
    });
  }

  Future<void> _toggleSave() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    setState(() => _saved = !_saved);
    final ref = FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('savedItems')
        .doc(widget.postId);
    if (_saved) {
      await ref.set({'type': 'post', 'postId': widget.postId, 'savedAt': FieldValue.serverTimestamp()});
    } else {
      await ref.delete();
    }
  }

  void _share() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Share link copied')),
    );
  }

  void _showComments() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFFFCE4EC),
      isScrollControlled: true,
      builder: (_) => PostCommentsSheet(postId: widget.postId),
    );
  }

  @override
  Widget build(BuildContext context) {
    final imageUrl = widget.data['imageUrl'] as String?;

    return Card(
      color: const Color(0xFFFCE4EC),
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if ((widget.data['text'] as String?)?.isNotEmpty ?? false)
              Text(widget.data['text'], style: const TextStyle(color: Colors.pink, fontSize: 15)),
            if (imageUrl != null) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(imageUrl, fit: BoxFit.cover, width: double.infinity),
              ),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                _PostAction(
                  icon: _liked ? Icons.favorite : Icons.favorite_border,
                  color: Colors.pink,
                  label: '${widget.data['likes'] ?? 0}',
                  onTap: _toggleLike,
                ),
                const SizedBox(width: 16),
                _PostAction(icon: Icons.comment_outlined, color: Colors.pink, label: 'Comment', onTap: _showComments),
                const SizedBox(width: 16),
                _PostAction(icon: Icons.share_outlined, color: Colors.pink, label: 'Share', onTap: _share),
                const Spacer(),
                IconButton(
                  icon: Icon(_saved ? Icons.bookmark : Icons.bookmark_border, color: const Color(0xFFD81B60)),
                  onPressed: _toggleSave,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _PostAction extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final VoidCallback onTap;

  const _PostAction({required this.icon, required this.color, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Row(
        children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(width: 4),
          Text(label, style: const TextStyle(color: const Color(0xFFD81B60), fontSize: 13)),
        ],
      ),
    );
  }
}

class PostCommentsSheet extends StatefulWidget {
  final String postId;
  const PostCommentsSheet({super.key, required this.postId});

  @override
  State<PostCommentsSheet> createState() => _PostCommentsSheetState();
}

class _PostCommentsSheetState extends State<PostCommentsSheet> {
  final _commentCtrl = TextEditingController();

  Future<void> _send() async {
    final text = _commentCtrl.text.trim();
    if (text.isEmpty) return;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.postId)
        .collection('comments')
        .add({'text': text, 'authorId': uid, 'createdAt': FieldValue.serverTimestamp()});
    _commentCtrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: 420,
        child: Column(
          children: [
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('posts')
                    .doc(widget.postId)
                    .collection('comments')
                    .orderBy('createdAt', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                  final docs = snapshot.data!.docs;
                  return ListView.builder(
                    itemCount: docs.length,
                    itemBuilder: (context, i) {
                      final data = docs[i].data() as Map<String, dynamic>;
                      return ListTile(
                        title: Text(data['text'] ?? '', style: const TextStyle(color: Colors.pink)),
                      );
                    },
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _commentCtrl,
                      style: const TextStyle(color: Colors.pink),
                      decoration: const InputDecoration(
                        hintText: 'Write a comment...',
                        hintStyle: TextStyle(color: const Color(0xFFF06292)),
                      ),
                    ),
                  ),
                  IconButton(icon: const Icon(Icons.send, color: Colors.pink), onPressed: _send),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
