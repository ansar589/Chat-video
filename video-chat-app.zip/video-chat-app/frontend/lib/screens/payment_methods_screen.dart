import 'package:flutter/material.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter_stripe/flutter_stripe.dart';

/// Lets the user save a debit/credit card OR a bank account for future
/// payments (used for boosting posts, buying coins, etc). Card and bank
/// details are collected by Stripe's own SDK — our backend and app never
/// see or store the raw numbers, only Stripe's payment-method ids.
class PaymentMethodsScreen extends StatefulWidget {
  const PaymentMethodsScreen({super.key});

  @override
  State<PaymentMethodsScreen> createState() => _PaymentMethodsScreenState();
}

class _PaymentMethodsScreenState extends State<PaymentMethodsScreen> {
  List<dynamic> _cards = [];
  List<dynamic> _bankAccounts = [];
  bool _loading = true;
  bool _adding = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadMethods();
  }

  Future<void> _loadMethods() async {
    setState(() => _loading = true);
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('listPaymentMethods');
      final result = await callable.call();
      setState(() {
        _cards = result.data['cards'] ?? [];
        _bankAccounts = result.data['bankAccounts'] ?? [];
      });
    } catch (e) {
      setState(() => _error = 'Could not load payment methods.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  /// Opens Stripe's own secure sheet to add either a card or a US bank
  /// account (ACH). Which one the user fills in depends on what they tap
  /// inside Stripe's payment sheet.
  Future<void> _addPaymentMethod() async {
    setState(() { _adding = true; _error = null; });
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('createSetupIntent');
      final result = await callable.call();
      final clientSecret = result.data['clientSecret'] as String;

      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          setupIntentClientSecret: clientSecret,
          merchantDisplayName: 'Video Chat App',
        ),
      );
      await Stripe.instance.presentPaymentSheet();

      await _loadMethods();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Payment method added.')),
        );
      }
    } catch (e) {
      setState(() => _error = 'Could not add payment method (cancelled or failed).');
    } finally {
      if (mounted) setState(() => _adding = false);
    }
  }

  Future<void> _remove(String id) async {
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('removePaymentMethod');
      await callable.call({'paymentMethodId': id});
      await _loadMethods();
    } catch (e) {
      setState(() => _error = 'Could not remove payment method.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('Payment Methods')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text(
                  'Add a debit/credit card or bank account. Stripe collects '
                  'these directly — we never see or store your card or '
                  'account number.',
                  style: TextStyle(color: const Color(0xFFEC407A), fontSize: 12),
                ),
                const SizedBox(height: 16),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text(_error!, style: const TextStyle(color: Colors.red)),
                  ),
                const Text('Cards', style: TextStyle(color: const Color(0xFFD81B60), fontWeight: FontWeight.bold)),
                if (_cards.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text('No cards saved', style: TextStyle(color: const Color(0xFFF06292))),
                  ),
                ..._cards.map((c) => Card(
                      color: const Color(0xFFFCE4EC),
                      child: ListTile(
                        leading: const Icon(Icons.credit_card, color: Colors.pink),
                        title: Text('${c['brand']} •••• ${c['last4']}',
                            style: const TextStyle(color: Colors.pink)),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline, color: const Color(0xFFF06292)),
                          onPressed: () => _remove(c['id']),
                        ),
                      ),
                    )),
                const SizedBox(height: 20),
                const Text('Bank Accounts', style: TextStyle(color: const Color(0xFFD81B60), fontWeight: FontWeight.bold)),
                if (_bankAccounts.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text('No bank accounts saved', style: TextStyle(color: const Color(0xFFF06292))),
                  ),
                ..._bankAccounts.map((b) => Card(
                      color: const Color(0xFFFCE4EC),
                      child: ListTile(
                        leading: const Icon(Icons.account_balance, color: Colors.pink),
                        title: Text('${b['bankName'] ?? 'Bank account'} •••• ${b['last4']}',
                            style: const TextStyle(color: Colors.pink)),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline, color: const Color(0xFFF06292)),
                          onPressed: () => _remove(b['id']),
                        ),
                      ),
                    )),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                  icon: _adding
                      ? const SizedBox(
                          width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.add),
                  label: const Text('Add Card or Bank Account'),
                  onPressed: _adding ? null : _addPaymentMethod,
                ),
              ],
            ),
    );
  }
}
