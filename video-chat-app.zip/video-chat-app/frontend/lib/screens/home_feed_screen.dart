import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'live_screen.dart';
import 'profile_screen.dart';
import 'music_picker_screen.dart';
import 'video_upload_screen.dart';
import 'boost_video_screen.dart';
import 'posts_feed_screen.dart';
import 'chat_list_screen.dart';
import '../services/prayer_times_service.dart';

class HomeFeedScreen extends StatefulWidget {
  const HomeFeedScreen({super.key});

  @override
  State<HomeFeedScreen> createState() => _HomeFeedScreenState();
}

class _HomeFeedScreenState extends State<HomeFeedScreen> {
  int _navIndex = 0;

  @override
  void initState() {
    super.initState();
    // Fetch + schedule today's Namaz reminders once on app open, so popup
    // notifications fire even if the user never opens the Prayer Times
    // screen directly.
    PrayerTimesService.fetchToday().then((prayers) {
      PrayerTimesService.scheduleNotifications(prayers);
    }).catchError((_) {
      // Silently ignore — user can retry from the Namaz Timings screen.
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      const VideoFeed(),
      const PostsFeedScreen(),
      const ChatListScreen(),
      const LiveScreen(),
      const ProfileScreen(),
    ];

    return Scaffold(
      body: pages[_navIndex],
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.pink,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        onPressed: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const PickVideoScreen())),
        child: const Icon(Icons.add, color: Colors.pink),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        color: Colors.white,
        shape: const CircularNotchedRectangle(),
        notchMargin: 8,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            IconButton(
              icon: Icon(Icons.home, color: _navIndex == 0 ? Colors.pink : const Color(0xFFEC407A), size: 22),
              onPressed: () => setState(() => _navIndex = 0),
            ),
            IconButton(
              icon: Icon(Icons.dynamic_feed, color: _navIndex == 1 ? Colors.pink : const Color(0xFFEC407A), size: 22),
              onPressed: () => setState(() => _navIndex = 1),
            ),
            IconButton(
              icon: Icon(Icons.chat_bubble, color: _navIndex == 2 ? Colors.pink : const Color(0xFFEC407A), size: 22),
              onPressed: () => setState(() => _navIndex = 2),
            ),
            const SizedBox(width: 32), // space for the notch/FAB
            IconButton(
              icon: Icon(Icons.live_tv, color: _navIndex == 3 ? Colors.pink : const Color(0xFFEC407A), size: 22),
              onPressed: () => setState(() => _navIndex = 3),
            ),
            IconButton(
              icon: Icon(Icons.person, color: _navIndex == 4 ? Colors.pink : const Color(0xFFEC407A), size: 22),
              onPressed: () => setState(() => _navIndex = 4),
            ),
          ],
        ),
      ),
    );
  }
}

class VideoFeed extends StatelessWidget {
  const VideoFeed({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('videos')
          .where('visibility', isEqualTo: 'public')
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final docs = snapshot.data!.docs;
        if (docs.isEmpty) {
          return const Center(
              child: Text('No videos yet', style: TextStyle(color: const Color(0xFFEC407A))));
        }
        return PageView.builder(
          scrollDirection: Axis.vertical,
          itemCount: docs.length,
          itemBuilder: (context, index) {
            final data = docs[index].data() as Map<String, dynamic>;
            return VideoCard(videoId: docs[index].id, data: data);
          },
        );
      },
    );
  }
}

class VideoCard extends StatefulWidget {
  final String videoId;
  final Map<String, dynamic> data;
  const VideoCard({super.key, required this.videoId, required this.data});

  @override
  State<VideoCard> createState() => _VideoCardState();
}

class _VideoCardState extends State<VideoCard> {
  bool _liked = false;

  Future<void> _toggleLike() async {
    setState(() => _liked = !_liked);
    final ref = FirebaseFirestore.instance.collection('videos').doc(widget.videoId);
    await ref.update({
      'likes': FieldValue.increment(_liked ? 1 : -1),
    });
  }

  Future<void> _saveVideo() async {
    // TODO: save reference into current user's "savedVideos" subcollection.
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Saved to your collection')),
    );
  }

  void _showComments() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFFFCE4EC),
      builder: (_) => CommentsSheet(videoId: widget.videoId),
    );
  }

  void _share() {
    // TODO: plug in share_plus package to open native share sheet.
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Share link copied')),
    );
  }

  void _chooseMusic() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const MusicPickerScreen()));
  }

  void _openBoost() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => BoostVideoScreen(videoId: widget.videoId)),
    );
  }

  bool get _isOwner =>
      FirebaseAuth.instance.currentUser?.uid == widget.data['ownerId'];

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        // TODO: replace with actual video player widget (e.g. video_player package)
        Container(color: const Color(0xFFFCE4EC)),
        Positioned(
          right: 12,
          bottom: 100,
          child: Column(
            children: [
              _ActionButton(
                icon: _liked ? Icons.favorite : Icons.favorite_border,
                color: Colors.pink,
                label: '${widget.data['likes'] ?? 0}',
                onTap: _toggleLike,
              ),
              const SizedBox(height: 20),
              _ActionButton(
                icon: Icons.comment,
                color: Colors.pink,
                label: 'Comments',
                onTap: _showComments,
              ),
              const SizedBox(height: 20),
              _ActionButton(
                icon: Icons.share,
                color: Colors.pink,
                label: 'Share',
                onTap: _share,
              ),
              const SizedBox(height: 20),
              _ActionButton(
                icon: Icons.bookmark_border,
                color: Colors.pink,
                label: 'Save',
                onTap: _saveVideo,
              ),
              const SizedBox(height: 20),
              _ActionButton(
                icon: Icons.music_note,
                color: Colors.pink,
                label: 'Music',
                onTap: _chooseMusic,
              ),
              if (_isOwner) ...[
                const SizedBox(height: 20),
                _ActionButton(
                  icon: Icons.rocket_launch,
                  color: Colors.orangeAccent,
                  label: 'Boost',
                  onTap: _openBoost,
                ),
              ],
            ],
          ),
        ),
        if ((widget.data['hashtags'] as List?)?.isNotEmpty ?? false)
          Positioned(
            left: 12,
            right: 80,
            bottom: 30,
            child: Wrap(
              spacing: 6,
              children: (widget.data['hashtags'] as List)
                  .map((tag) => Text('#$tag',
                      style: const TextStyle(color: Colors.pink, fontWeight: FontWeight.bold)))
                  .toList(),
            ),
          ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.color,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Icon(icon, color: color, size: 32),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(color: Colors.pink, fontSize: 12)),
        ],
      ),
    );
  }
}

class CommentsSheet extends StatelessWidget {
  final String videoId;
  const CommentsSheet({super.key, required this.videoId});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 400,
      child: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('videos')
            .doc(videoId)
            .collection('comments')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data!.docs;
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, i) {
              final data = docs[i].data() as Map<String, dynamic>;
              return ListTile(
                title: Text(data['text'] ?? '', style: const TextStyle(color: Colors.pink)),
              );
            },
          );
        },
      ),
    );
  }
}
