import 'dart:async';
import 'package:flutter/material.dart';
import '../services/prayer_times_service.dart';

class PrayerTimesScreen extends StatefulWidget {
  const PrayerTimesScreen({super.key});

  @override
  State<PrayerTimesScreen> createState() => _PrayerTimesScreenState();
}

class _PrayerTimesScreenState extends State<PrayerTimesScreen> {
  List<PrayerTime>? _prayers;
  bool _loading = true;
  String? _error;
  bool _remindersOn = true;
  Timer? _popupChecker;
  String? _lastPoppedPrayer;

  @override
  void initState() {
    super.initState();
    _load();
    // While this screen (or app) is open, also check every 30s and show an
    // in-app popup dialog exactly at prayer time — in addition to the
    // system notification scheduled in PrayerTimesService.
    _popupChecker = Timer.periodic(const Duration(seconds: 30), (_) => _checkForPopup());
  }

  @override
  void dispose() {
    _popupChecker?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final prayers = await PrayerTimesService.fetchToday();
      setState(() => _prayers = prayers);
      if (_remindersOn) {
        await PrayerTimesService.scheduleNotifications(prayers);
      }
    } catch (e) {
      setState(() => _error = 'Could not load prayer times. Check your connection.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _checkForPopup() {
    if (_prayers == null) return;
    final now = TimeOfDay.now();
    final nowStr =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    for (final p in _prayers!) {
      if (p.time == nowStr && _lastPoppedPrayer != p.name) {
        _lastPoppedPrayer = p.name;
        _showPopup(p);
        break;
      }
    }
  }

  void _showPopup(PrayerTime prayer) {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFCE4EC),
        title: Row(
          children: [
            const Icon(Icons.mosque, color: Colors.pink),
            const SizedBox(width: 10),
            Text('${prayer.name} Time', style: const TextStyle(color: Colors.pink)),
          ],
        ),
        content: Text(
          'It\'s time for ${prayer.name} prayer (${prayer.time}).',
          style: const TextStyle(color: const Color(0xFFD81B60)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK', style: TextStyle(color: Colors.pinkAccent)),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleReminders(bool value) async {
    setState(() => _remindersOn = value);
    if (value && _prayers != null) {
      await PrayerTimesService.scheduleNotifications(_prayers!);
    } else {
      // cancelAll is called inside scheduleNotifications; call the same
      // effect here when turning reminders off.
      await PrayerTimesService.scheduleNotifications([]);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Namaz Timings'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!, style: const TextStyle(color: Colors.red)))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    SwitchListTile(
                      activeColor: Colors.pink,
                      title: const Text('Popup Reminders', style: TextStyle(color: Colors.pink)),
                      subtitle: const Text(
                        'Show a popup and notification at each prayer time',
                        style: TextStyle(color: const Color(0xFFEC407A), fontSize: 12),
                      ),
                      value: _remindersOn,
                      onChanged: _toggleReminders,
                    ),
                    const SizedBox(height: 12),
                    const Text('Lahore, Pakistan',
                        style: TextStyle(color: const Color(0xFFF06292), fontSize: 12)),
                    const SizedBox(height: 8),
                    ...?_prayers?.map((p) => Card(
                          color: const Color(0xFFFCE4EC),
                          child: ListTile(
                            leading: const Icon(Icons.mosque, color: Colors.pink),
                            title: Text(p.name, style: const TextStyle(color: Colors.pink)),
                            trailing: Text(p.time,
                                style: const TextStyle(color: Colors.pink, fontSize: 16)),
                          ),
                        )),
                  ],
                ),
    );
  }
}
