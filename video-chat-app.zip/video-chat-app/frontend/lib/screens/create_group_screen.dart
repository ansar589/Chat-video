import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'group_chat_screen.dart';

class CreateGroupScreen extends StatefulWidget {
  const CreateGroupScreen({super.key});

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _nameCtrl = TextEditingController();
  final _searchCtrl = TextEditingController();
  final Map<String, String> _selected = {}; // uid -> displayName
  List<Map<String, dynamic>> _results = [];
  bool _searching = false;
  bool _creating = false;
  String? _error;

  Future<void> _search(String query) async {
    if (query.trim().isEmpty) {
      setState(() => _results = []);
      return;
    }
    setState(() => _searching = true);
    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .orderBy('displayName')
        .startAt([query])
        .endAt(['$query\uf8ff'])
        .limit(20)
        .get();

    final myUid = FirebaseAuth.instance.currentUser?.uid;
    setState(() {
      _results = snapshot.docs
          .where((d) => d.id != myUid)
          .map((d) => {'uid': d.id, 'displayName': d.data()['displayName'] ?? 'User'})
          .toList();
      _searching = false;
    });
  }

  void _toggleSelect(String uid, String name) {
    setState(() {
      if (_selected.containsKey(uid)) {
        _selected.remove(uid);
      } else {
        _selected[uid] = name;
      }
    });
  }

  Future<void> _createGroup() async {
    final myUid = FirebaseAuth.instance.currentUser?.uid;
    final myName = FirebaseAuth.instance.currentUser?.displayName ?? 'You';
    if (myUid == null) return;

    if (_nameCtrl.text.trim().isEmpty) {
      setState(() => _error = 'Enter a group name.');
      return;
    }
    if (_selected.length < 2) {
      setState(() => _error = 'Pick at least 2 members.');
      return;
    }

    setState(() { _creating = true; _error = null; });

    final participants = [myUid, ..._selected.keys];
    final participantNames = {myUid: myName, ..._selected};

    final docRef = await FirebaseFirestore.instance.collection('groups').add({
      'name': _nameCtrl.text.trim(),
      'photoUrl': null,
      'participants': participants,
      'participantNames': participantNames,
      'admins': [myUid],
      'createdBy': myUid,
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessage': '',
      'lastMessageType': 'text',
      'lastMessageAt': FieldValue.serverTimestamp(),
    });

    setState(() => _creating = false);
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => GroupChatScreen(groupId: docRef.id, groupName: _nameCtrl.text.trim()),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('New Group'),
        actions: [
          TextButton(
            onPressed: _creating ? null : _createGroup,
            child: _creating
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Create', style: TextStyle(color: Colors.pinkAccent)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameCtrl,
              style: const TextStyle(color: Colors.pink),
              decoration: const InputDecoration(
                labelText: 'Group name',
                labelStyle: TextStyle(color: const Color(0xFFEC407A)),
              ),
            ),
            const SizedBox(height: 12),
            if (_selected.isNotEmpty) ...[
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: _selected.entries
                    .map((e) => Chip(
                          label: Text(e.value, style: const TextStyle(color: Colors.white, fontSize: 12)),
                          backgroundColor: const Color(0xFFC2185B),
                          onDeleted: () => _toggleSelect(e.key, e.value),
                          deleteIcon: const Icon(Icons.close, size: 14, color: Colors.white),
                        ))
                    .toList(),
              ),
              const SizedBox(height: 12),
            ],
            TextField(
              controller: _searchCtrl,
              style: const TextStyle(color: Colors.pink),
              decoration: const InputDecoration(
                hintText: 'Search people by name',
                hintStyle: TextStyle(color: const Color(0xFFF06292)),
                prefixIcon: Icon(Icons.search, color: const Color(0xFFEC407A)),
              ),
              onChanged: _search,
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12)),
            ],
            const SizedBox(height: 8),
            Expanded(
              child: _searching
                  ? const Center(child: CircularProgressIndicator())
                  : ListView.builder(
                      itemCount: _results.length,
                      itemBuilder: (context, i) {
                        final uid = _results[i]['uid'] as String;
                        final name = _results[i]['displayName'] as String;
                        final isSelected = _selected.containsKey(uid);
                        return ListTile(
                          leading: CircleAvatar(
                              backgroundColor: const Color(0xFFC2185B),
                              child: const Icon(Icons.person, color: Colors.white)),
                          title: Text(name, style: const TextStyle(color: Colors.pink)),
                          trailing: Icon(
                            isSelected ? Icons.check_circle : Icons.circle_outlined,
                            color: isSelected ? Colors.pink : const Color(0xFFF48FB1),
                          ),
                          onTap: () => _toggleSelect(uid, name),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
