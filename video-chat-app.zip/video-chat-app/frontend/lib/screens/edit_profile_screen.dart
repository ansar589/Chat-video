import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:country_code_picker/country_code_picker.dart';
import '../models/user_model.dart';

class EditProfileScreen extends StatefulWidget {
  final AppUser user;
  const EditProfileScreen({super.key, required this.user});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _bioCtrl;
  late final TextEditingController _youtubeCtrl;
  late final TextEditingController _whatsappCtrl;
  late final TextEditingController _facebookCtrl;
  late final TextEditingController _telegramCtrl;
  late final TextEditingController _discordCtrl;
  late final TextEditingController _phoneCtrl;

  File? _newPhoto;
  bool _saving = false;
  String? _error;
  String _dialCode = '+92'; // defaults to Pakistan, matching this app's base location

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.user.displayName);
    _bioCtrl = TextEditingController(text: widget.user.bio);
    _youtubeCtrl = TextEditingController(text: widget.user.socialLinks['youtube'] ?? '');
    _whatsappCtrl = TextEditingController(text: widget.user.socialLinks['whatsapp'] ?? '');
    _facebookCtrl = TextEditingController(text: widget.user.socialLinks['facebook'] ?? '');
    _telegramCtrl = TextEditingController(text: widget.user.socialLinks['telegram'] ?? '');
    _discordCtrl = TextEditingController(text: widget.user.socialLinks['discord'] ?? '');

    // Split a stored E.164 number (e.g. "+923001234567") into dial code +
    // local digits so the picker and text field show them separately.
    final existingPhone = widget.user.phoneNumber;
    if (existingPhone != null && existingPhone.startsWith('+')) {
      final match = RegExp(r'^(\+\d{1,4})(\d+)$').firstMatch(existingPhone);
      if (match != null) {
        _dialCode = match.group(1)!;
        _phoneCtrl = TextEditingController(text: match.group(2));
      } else {
        _phoneCtrl = TextEditingController();
      }
    } else {
      _phoneCtrl = TextEditingController();
    }
  }

  /// Picks a photo, then opens a simple crop/rotate editor before it's used
  /// as the profile picture.
  Future<void> _pickAndEditPhoto() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (picked == null) return;

    final cropped = await ImageCropper().cropImage(
      sourcePath: picked.path,
      aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
      compressQuality: 90,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Edit Profile Picture',
          toolbarColor: Colors.black,
          toolbarWidgetColor: Colors.pink,
          initAspectRatio: CropAspectRatioPreset.square,
          lockAspectRatio: true,
          cropStyle: CropStyle.circle,
        ),
        IOSUiSettings(
          title: 'Edit Profile Picture',
          aspectRatioLockEnabled: true,
          cropStyle: CropStyle.circle,
        ),
      ],
    );

    if (cropped != null) {
      setState(() => _newPhoto = File(cropped.path));
    }
  }

  Future<void> _save() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    setState(() { _saving = true; _error = null; });

    try {
      String? photoUrl = widget.user.photoUrl;
      if (_newPhoto != null) {
        final ref = FirebaseStorage.instance.ref('profile_pictures/$uid.jpg');
        await ref.putFile(_newPhoto!);
        photoUrl = await ref.getDownloadURL();
      }

      await FirebaseFirestore.instance.collection('users').doc(uid).update({
        'displayName': _nameCtrl.text.trim(),
        'bio': _bioCtrl.text.trim(),
        if (photoUrl != null) 'photoUrl': photoUrl,
        'socialLinks': {
          'youtube': _youtubeCtrl.text.trim(),
          'whatsapp': _whatsappCtrl.text.trim(),
          'facebook': _facebookCtrl.text.trim(),
          'telegram': _telegramCtrl.text.trim(),
          'discord': _discordCtrl.text.trim(),
        },
      });

      // phoneNumber is deliberately NOT included in the update above —
      // Firestore rules block writing it directly, so it always goes
      // through this Cloud Function, which validates the E.164 format.
      final localDigits = _phoneCtrl.text.trim();
      final callable = FirebaseFunctions.instance.httpsCallable('updatePhoneNumber');
      await callable.call({
        'phoneNumber': localDigits.isEmpty ? null : '$_dialCode$localDigits',
      });

      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => _error = 'Could not save profile. Please try again.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _linkField(TextEditingController ctrl, String label, IconData icon, String hint) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: ctrl,
        style: const TextStyle(color: Colors.pink),
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: const Color(0xFFEC407A)),
          labelText: label,
          labelStyle: const TextStyle(color: const Color(0xFFEC407A)),
          hintText: hint,
          hintStyle: const TextStyle(color: const Color(0xFFF48FB1)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Edit Profile'),
        actions: [
          TextButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Save', style: TextStyle(color: Colors.pinkAccent)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: GestureDetector(
              onTap: _pickAndEditPhoto,
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: const Color(0xFFC2185B),
                    backgroundImage: _newPhoto != null
                        ? FileImage(_newPhoto!)
                        : (widget.user.photoUrl != null
                            ? NetworkImage(widget.user.photoUrl!)
                            : null) as ImageProvider?,
                    child: (_newPhoto == null && widget.user.photoUrl == null)
                        ? const Icon(Icons.person, size: 40, color: Colors.pink)
                        : null,
                  ),
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: CircleAvatar(
                      radius: 16,
                      backgroundColor: Colors.pink,
                      child: const Icon(Icons.edit, size: 16, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          TextField(
            controller: _nameCtrl,
            style: const TextStyle(color: Colors.pink),
            decoration: const InputDecoration(labelText: 'Display Name', labelStyle: TextStyle(color: const Color(0xFFEC407A))),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _bioCtrl,
            style: const TextStyle(color: Colors.pink),
            maxLines: 3,
            maxLength: 150,
            decoration: const InputDecoration(
              labelText: 'Bio',
              labelStyle: TextStyle(color: const Color(0xFFEC407A)),
              hintText: 'Tell people about yourself...',
              hintStyle: TextStyle(color: const Color(0xFFF48FB1)),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Phone Number', style: TextStyle(color: const Color(0xFFD81B60), fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(
            children: [
              Container(
                decoration: BoxDecoration(border: Border.all(color: const Color(0xFFF48FB1)), borderRadius: BorderRadius.circular(8)),
                child: CountryCodePicker(
                  onChanged: (country) => setState(() => _dialCode = country.dialCode ?? '+92'),
                  initialSelection: 'PK',
                  favorite: const ['+92', 'PK', '+1', 'US', '+44', 'GB', '+91', 'IN', '+966', 'SA'],
                  showCountryOnly: false,
                  showOnlyCountryWhenClosed: false,
                  alignLeft: false,
                  textStyle: const TextStyle(color: Colors.pink),
                  backgroundColor: const Color(0xFFFCE4EC),
                  dialogBackgroundColor: const Color(0xFFFCE4EC),
                  searchStyle: const TextStyle(color: Colors.pink),
                  dialogTextStyle: const TextStyle(color: Colors.pink),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _phoneCtrl,
                  keyboardType: TextInputType.phone,
                  style: const TextStyle(color: Colors.pink),
                  decoration: const InputDecoration(
                    hintText: '3001234567',
                    hintStyle: TextStyle(color: const Color(0xFFF48FB1)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Social Links', style: TextStyle(color: const Color(0xFFD81B60), fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          _linkField(_youtubeCtrl, 'YouTube', Icons.play_circle_fill, 'https://youtube.com/@yourchannel'),
          _linkField(_whatsappCtrl, 'WhatsApp', Icons.chat, 'https://wa.me/92XXXXXXXXXX'),
          _linkField(_facebookCtrl, 'Facebook', Icons.facebook, 'https://facebook.com/yourprofile'),
          _linkField(_telegramCtrl, 'Telegram', Icons.send, 'https://t.me/yourusername'),
          _linkField(_discordCtrl, 'Discord', Icons.discord, 'https://discord.gg/yourinvite'),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
        ],
      ),
    );
  }
}
