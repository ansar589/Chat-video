import 'package:flutter/material.dart';
import '../services/payment_service.dart';

class CoinPackage {
  final String id;
  final String label;
  final int coins;
  final String priceLabel;
  const CoinPackage(this.id, this.label, this.coins, this.priceLabel);
}

// Must mirror COIN_PACKAGES on the backend (backend is the source of truth
// for actual price charged — this is just for display).
const List<CoinPackage> coinPackages = [
  CoinPackage('small', 'Starter Pack', 100, '\$1.99'),
  CoinPackage('medium', 'Popular Pack', 550, '\$9.99'),
  CoinPackage('large', 'Best Value Pack', 1200, '\$19.99'),
];

class BuyCoinsScreen extends StatefulWidget {
  const BuyCoinsScreen({super.key});

  @override
  State<BuyCoinsScreen> createState() => _BuyCoinsScreenState();
}

class _BuyCoinsScreenState extends State<BuyCoinsScreen> {
  final _payment = PaymentService();
  bool _loading = false;
  String? _error;

  Future<void> _buy(String packageId) async {
    setState(() { _loading = true; _error = null; });
    try {
      await _payment.buyCoins(packageId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Payment successful! Coins added.')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      setState(() => _error = 'Payment failed or cancelled.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('Buy Coins')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Pay securely with your credit or debit card. Card details are '
              'handled directly by Stripe — we never see or store your card number.',
              style: TextStyle(color: const Color(0xFFEC407A), fontSize: 12),
            ),
            const SizedBox(height: 16),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(_error!, style: const TextStyle(color: Colors.red)),
              ),
            ...coinPackages.map((pkg) => Card(
                  color: const Color(0xFFFCE4EC),
                  child: ListTile(
                    leading: const Icon(Icons.monetization_on, color: Colors.pink),
                    title: Text('${pkg.coins} coins', style: const TextStyle(color: Colors.pink)),
                    subtitle: Text(pkg.label, style: const TextStyle(color: const Color(0xFFEC407A))),
                    trailing: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                      onPressed: _loading ? null : () => _buy(pkg.id),
                      child: Text(pkg.priceLabel),
                    ),
                  ),
                )),
            if (_loading) const Padding(
              padding: EdgeInsets.only(top: 20),
              child: Center(child: CircularProgressIndicator()),
            ),
          ],
        ),
      ),
    );
  }
}
