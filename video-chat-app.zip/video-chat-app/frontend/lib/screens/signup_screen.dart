import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:country_code_picker/country_code_picker.dart';
import '../services/auth_service.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _auth = AuthService();
  final _firstNameCtrl = TextEditingController();
  final _lastNameCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  String _dialCode = '+92'; // defaults to Pakistan, matching this app's base location
  final _referralCtrl = TextEditingController();

  DateTime? _dob;
  bool _loading = false;
  String? _error;

  bool? _usernameAvailable;
  bool _checkingUsername = false;
  Timer? _debounce;

  void _onUsernameChanged(String value) {
    _debounce?.cancel();
    setState(() => _usernameAvailable = null);
    if (value.trim().length < 3) return;

    _debounce = Timer(const Duration(milliseconds: 500), () async {
      setState(() => _checkingUsername = true);
      try {
        final callable = FirebaseFunctions.instance.httpsCallable('checkUsernameAvailable');
        final result = await callable.call({'username': value.trim()});
        setState(() => _usernameAvailable = result.data['available'] as bool);
      } catch (e) {
        setState(() => _usernameAvailable = null);
      } finally {
        if (mounted) setState(() => _checkingUsername = false);
      }
    });
  }

  Future<void> _pickDob() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime(now.year - 18, now.month, now.day),
      firstDate: DateTime(now.year - 100),
      lastDate: now,
    );
    if (picked != null) setState(() => _dob = picked);
  }

  Future<void> _signUp() async {
    setState(() { _error = null; });

    if (_firstNameCtrl.text.trim().isEmpty || _lastNameCtrl.text.trim().isEmpty) {
      setState(() => _error = 'Enter your first and last name.');
      return;
    }
    if (_usernameAvailable != true) {
      setState(() => _error = 'Choose an available username.');
      return;
    }
    if (_dob == null) {
      setState(() => _error = 'Select your date of birth.');
      return;
    }

    setState(() => _loading = true);
    try {
      final displayName = '${_firstNameCtrl.text.trim()} ${_lastNameCtrl.text.trim()}';
      await _auth.signUpWithEmail(
        email: _emailCtrl.text.trim(),
        password: _passCtrl.text,
        displayName: displayName,
        username: _usernameCtrl.text.trim(),
        firstName: _firstNameCtrl.text.trim(),
        lastName: _lastNameCtrl.text.trim(),
        dateOfBirth: _dob!,
        phoneNumber: _phoneCtrl.text.trim().isEmpty ? null : '$_dialCode${_phoneCtrl.text.trim()}',
        referralCode: _referralCtrl.text.trim().isEmpty ? null : _referralCtrl.text.trim(),
      );
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  Widget _field(TextEditingController ctrl, String label, {bool obscure = false, TextInputType? type}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: ctrl,
        obscureText: obscure,
        keyboardType: type,
        style: const TextStyle(color: Colors.pink),
        decoration: InputDecoration(labelText: label, labelStyle: const TextStyle(color: const Color(0xFFEC407A))),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Account')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: ListView(
            children: [
              Row(
                children: [
                  Expanded(child: _field(_firstNameCtrl, 'First Name')),
                  const SizedBox(width: 10),
                  Expanded(child: _field(_lastNameCtrl, 'Last Name')),
                ],
              ),
              TextField(
                controller: _usernameCtrl,
                style: const TextStyle(color: Colors.pink),
                decoration: InputDecoration(
                  labelText: 'Username',
                  labelStyle: const TextStyle(color: const Color(0xFFEC407A)),
                  suffixIcon: _checkingUsername
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)))
                      : _usernameAvailable == null
                          ? null
                          : Icon(
                              _usernameAvailable! ? Icons.check_circle : Icons.cancel,
                              color: _usernameAvailable! ? Colors.greenAccent : Colors.red,
                            ),
                ),
                onChanged: _onUsernameChanged,
              ),
              const SizedBox(height: 10),
              _field(_emailCtrl, 'Email', type: TextInputType.emailAddress),
              _field(_passCtrl, 'Password', obscure: true),
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  children: [
                    Container(
                      decoration: BoxDecoration(border: Border.all(color: const Color(0xFFF48FB1)), borderRadius: BorderRadius.circular(8)),
                      child: CountryCodePicker(
                        onChanged: (country) => setState(() => _dialCode = country.dialCode ?? '+92'),
                        initialSelection: 'PK',
                        favorite: const ['+92', 'PK', '+1', 'US', '+44', 'GB', '+91', 'IN', '+966', 'SA'],
                        textStyle: const TextStyle(color: Colors.pink),
                        backgroundColor: const Color(0xFFFCE4EC),
                        dialogBackgroundColor: const Color(0xFFFCE4EC),
                        searchStyle: const TextStyle(color: Colors.pink),
                        dialogTextStyle: const TextStyle(color: Colors.pink),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: _phoneCtrl,
                        keyboardType: TextInputType.phone,
                        style: const TextStyle(color: Colors.pink),
                        decoration: const InputDecoration(
                          labelText: 'Phone Number (optional)',
                          labelStyle: TextStyle(color: const Color(0xFFEC407A)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              InkWell(
                onTap: _pickDob,
                child: InputDecorator(
                  decoration: const InputDecoration(labelText: 'Date of Birth', labelStyle: TextStyle(color: const Color(0xFFEC407A))),
                  child: Text(
                    _dob == null ? 'Select date' : '${_dob!.year}-${_dob!.month.toString().padLeft(2, '0')}-${_dob!.day.toString().padLeft(2, '0')}',
                    style: const TextStyle(color: Colors.pink),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              _field(_referralCtrl, 'Referral Code (optional)'),
              const SizedBox(height: 8),
              if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: _loading ? null : _signUp,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                child: _loading ? const CircularProgressIndicator() : const Text('Sign Up'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
