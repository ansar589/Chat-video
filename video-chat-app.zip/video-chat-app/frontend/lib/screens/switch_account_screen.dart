import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/account_store.dart';
import '../services/auth_service.dart';
import 'signin_screen.dart';

class SwitchAccountScreen extends StatefulWidget {
  const SwitchAccountScreen({super.key});

  @override
  State<SwitchAccountScreen> createState() => _SwitchAccountScreenState();
}

class _SwitchAccountScreenState extends State<SwitchAccountScreen> {
  List<RememberedAccount> _accounts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final accounts = await AccountStore.getAll();
    setState(() { _accounts = accounts; _loading = false; });
  }

  /// Switching accounts (or adding a new one) signs out of the current
  /// session and goes to Sign In. This app keeps only one Firebase Auth
  /// session live at a time — see README for what true simultaneous
  /// multi-account (like Gmail) would require.
  Future<void> _switchOrAdd({String? prefillEmail}) async {
    await AuthService().signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => SignInScreen(prefillEmail: prefillEmail)),
      (route) => false,
    );
  }

  Future<void> _forget(String uid) async {
    await AccountStore.forget(uid);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final currentUid = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('Switch Account')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              children: [
                ..._accounts.map((a) => ListTile(
                      leading: CircleAvatar(backgroundColor: const Color(0xFFC2185B), child: const Icon(Icons.person, color: Colors.white)),
                      title: Text(a.displayName, style: const TextStyle(color: Colors.pink)),
                      subtitle: Text(a.email, style: const TextStyle(color: const Color(0xFFEC407A))),
                      trailing: a.uid == currentUid
                          ? const Icon(Icons.check_circle, color: Colors.pink)
                          : IconButton(
                              icon: const Icon(Icons.close, color: const Color(0xFFF06292), size: 18),
                              onPressed: () => _forget(a.uid),
                            ),
                      onTap: a.uid == currentUid ? null : () => _switchOrAdd(prefillEmail: a.email),
                    )),
                const Divider(color: const Color(0xFFF48FB1)),
                ListTile(
                  leading: const Icon(Icons.person_add, color: Colors.pink),
                  title: const Text('Add another account', style: TextStyle(color: Colors.pink)),
                  onTap: () => _switchOrAdd(),
                ),
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Switching signs you out of the current account — you\'ll need '
                    'its password (or Google/phone sign-in) again to continue.',
                    style: TextStyle(color: const Color(0xFFF06292), fontSize: 11),
                  ),
                ),
              ],
            ),
    );
  }
}
