import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class GroupInfoScreen extends StatelessWidget {
  final String groupId;
  final String groupName;
  const GroupInfoScreen({super.key, required this.groupId, required this.groupName});

  @override
  Widget build(BuildContext context) {
    final myUid = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: Text(groupName)),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('groups').doc(groupId).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snapshot.data!.data() as Map<String, dynamic>;
          final participants = List<String>.from(data['participants'] ?? []);
          final admins = List<String>.from(data['admins'] ?? []);
          final names = Map<String, dynamic>.from(data['participantNames'] ?? {});
          final isAdmin = admins.contains(myUid);

          return ListView(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    CircleAvatar(radius: 32, backgroundColor: const Color(0xFFC2185B), child: const Icon(Icons.group, color: Colors.white)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(groupName, style: const TextStyle(color: Colors.pink, fontSize: 18, fontWeight: FontWeight.bold)),
                          Text('${participants.length} members', style: const TextStyle(color: const Color(0xFFEC407A), fontSize: 12)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const Divider(color: const Color(0xFFF48FB1)),
              ...participants.map((uid) {
                final name = names[uid] ?? 'User';
                final isThatAdmin = admins.contains(uid);
                final isMe = uid == myUid;
                return ListTile(
                  leading: CircleAvatar(backgroundColor: const Color(0xFFC2185B), child: const Icon(Icons.person, color: Colors.white)),
                  title: Text(isMe ? '$name (you)' : name, style: const TextStyle(color: Colors.pink)),
                  subtitle: isThatAdmin ? const Text('Admin', style: TextStyle(color: Colors.pinkAccent, fontSize: 11)) : null,
                  trailing: (isAdmin && !isMe)
                      ? IconButton(
                          icon: const Icon(Icons.person_remove, color: const Color(0xFFEC407A)),
                          onPressed: () => _removeMember(context, participants, names, admins, uid),
                        )
                      : null,
                );
              }),
              const Divider(color: const Color(0xFFF48FB1)),
              Padding(
                padding: const EdgeInsets.all(16),
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.red)),
                  icon: const Icon(Icons.exit_to_app, color: Colors.red),
                  label: const Text('Leave group', style: TextStyle(color: Colors.red)),
                  onPressed: () => _leaveGroup(context, participants, admins),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _removeMember(
    BuildContext context,
    List<String> participants,
    Map<String, dynamic> names,
    List<String> admins,
    String uidToRemove,
  ) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFCE4EC),
        title: const Text('Remove member?', style: TextStyle(color: Colors.pink)),
        content: Text('Remove ${names[uidToRemove] ?? 'this member'} from the group?',
            style: const TextStyle(color: const Color(0xFFD81B60))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Remove')),
        ],
      ),
    );
    if (confirm != true) return;

    final newParticipants = participants.where((p) => p != uidToRemove).toList();
    final newAdmins = admins.where((a) => a != uidToRemove).toList();

    await FirebaseFirestore.instance.collection('groups').doc(groupId).update({
      'participants': newParticipants,
      'admins': newAdmins.isEmpty ? [FirebaseAuth.instance.currentUser!.uid] : newAdmins,
    });
  }

  Future<void> _leaveGroup(BuildContext context, List<String> participants, List<String> admins) async {
    final myUid = FirebaseAuth.instance.currentUser!.uid;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFCE4EC),
        title: const Text('Leave group?', style: TextStyle(color: Colors.pink)),
        content: const Text('You will no longer receive messages from this group.',
            style: TextStyle(color: const Color(0xFFD81B60))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Leave')),
        ],
      ),
    );
    if (confirm != true) return;

    final myIsAdmin = admins.contains(myUid);
    final newParticipants = participants.where((p) => p != myUid).toList();

    if (myIsAdmin) {
      // Being an admin lets this write go through the "admin can change
      // anything" rule branch, so participants + admins can both update
      // in one call — remove self from admins, and if that empties the
      // list, promote the first remaining participant.
      var newAdmins = admins.where((a) => a != myUid).toList();
      if (newAdmins.isEmpty && newParticipants.isNotEmpty) {
        newAdmins = [newParticipants.first];
      }
      await FirebaseFirestore.instance.collection('groups').doc(groupId).update({
        'participants': newParticipants,
        'admins': newAdmins,
      });
    } else {
      // Only 'participants' changes — matches the "member can remove
      // themself" rule branch, which requires no other field to change.
      await FirebaseFirestore.instance.collection('groups').doc(groupId).update({
        'participants': newParticipants,
      });
    }

    if (context.mounted) {
      Navigator.popUntil(context, (route) => route.isFirst);
    }
  }
}
