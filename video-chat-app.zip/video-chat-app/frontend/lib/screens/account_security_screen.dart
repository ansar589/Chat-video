import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:country_code_picker/country_code_picker.dart';

class AccountSecurityScreen extends StatefulWidget {
  const AccountSecurityScreen({super.key});

  @override
  State<AccountSecurityScreen> createState() => _AccountSecurityScreenState();
}

class _AccountSecurityScreenState extends State<AccountSecurityScreen> {
  bool _twoStepEnabled = false;
  bool _loadingTwoStep = true;

  @override
  void initState() {
    super.initState();
    _loadTwoStepStatus();
  }

  Future<void> _loadTwoStepStatus() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    setState(() {
      _twoStepEnabled = doc.data()?['twoStepEnabled'] ?? false;
      _loadingTwoStep = false;
    });
  }

  /// Re-authentication is required by Firebase before sensitive changes
  /// (password/email) if the user's last sign-in was a while ago.
  Future<bool> _reauthenticate(String currentPassword) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.email == null) return false;
    try {
      final cred = EmailAuthProvider.credential(email: user.email!, password: currentPassword);
      await user.reauthenticateWithCredential(cred);
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<void> _showChangePasswordDialog() async {
    final currentCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    String? error;

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFFFCE4EC),
          title: const Text('Change Password', style: TextStyle(color: Colors.pink)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: currentCtrl,
                obscureText: true,
                style: const TextStyle(color: Colors.pink),
                decoration: const InputDecoration(labelText: 'Current password', labelStyle: TextStyle(color: const Color(0xFFEC407A))),
              ),
              TextField(
                controller: newCtrl,
                obscureText: true,
                style: const TextStyle(color: Colors.pink),
                decoration: const InputDecoration(labelText: 'New password', labelStyle: TextStyle(color: const Color(0xFFEC407A))),
              ),
              if (error != null) ...[
                const SizedBox(height: 8),
                Text(error!, style: const TextStyle(color: Colors.red, fontSize: 12)),
              ],
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            TextButton(
              onPressed: () async {
                if (newCtrl.text.length < 6) {
                  setDialogState(() => error = 'New password must be at least 6 characters.');
                  return;
                }
                final ok = await _reauthenticate(currentCtrl.text);
                if (!ok) {
                  setDialogState(() => error = 'Current password is incorrect.');
                  return;
                }
                try {
                  await FirebaseAuth.instance.currentUser!.updatePassword(newCtrl.text);
                  if (context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(this.context)
                        .showSnackBar(const SnackBar(content: Text('Password updated.')));
                  }
                } catch (e) {
                  setDialogState(() => error = 'Could not update password.');
                }
              },
              child: const Text('Update', style: TextStyle(color: Colors.pinkAccent)),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showChangeEmailDialog() async {
    final passwordCtrl = TextEditingController();
    final newEmailCtrl = TextEditingController();
    String? error;

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFFFCE4EC),
          title: const Text('Change Email', style: TextStyle(color: Colors.pink)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: newEmailCtrl,
                keyboardType: TextInputType.emailAddress,
                style: const TextStyle(color: Colors.pink),
                decoration: const InputDecoration(labelText: 'New email', labelStyle: TextStyle(color: const Color(0xFFEC407A))),
              ),
              TextField(
                controller: passwordCtrl,
                obscureText: true,
                style: const TextStyle(color: Colors.pink),
                decoration: const InputDecoration(labelText: 'Current password', labelStyle: TextStyle(color: const Color(0xFFEC407A))),
              ),
              if (error != null) ...[
                const SizedBox(height: 8),
                Text(error!, style: const TextStyle(color: Colors.red, fontSize: 12)),
              ],
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            TextButton(
              onPressed: () async {
                final ok = await _reauthenticate(passwordCtrl.text);
                if (!ok) {
                  setDialogState(() => error = 'Current password is incorrect.');
                  return;
                }
                try {
                  // Sends a verification link to the NEW address; the email
                  // only actually changes once the user clicks it — safer
                  // than updateEmail(), which switches immediately.
                  await FirebaseAuth.instance.currentUser!.verifyBeforeUpdateEmail(newEmailCtrl.text.trim());
                  if (context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(this.context).showSnackBar(
                      const SnackBar(content: Text('Verification link sent to your new email.')),
                    );
                  }
                } catch (e) {
                  setDialogState(() => error = 'Could not update email.');
                }
              },
              child: const Text('Update', style: TextStyle(color: Colors.pinkAccent)),
            ),
          ],
        ),
      ),
    );
  }

  /// Two-step verification, implemented as Firebase Auth's phone-based
  /// multi-factor authentication: after enrollment, sign-in on a NEW
  /// device also requires an SMS code sent to this phone.
  Future<void> _toggleTwoStep(bool enable) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    if (!enable) {
      // Disabling: unenroll all second factors.
      try {
        final enrolled = user.multiFactor.enrolledFactors;
        for (final factor in enrolled) {
          await user.multiFactor.unenroll(factorUid: factor.uid);
        }
        await FirebaseFirestore.instance.collection('users').doc(user.uid).update({'twoStepEnabled': false});
        setState(() => _twoStepEnabled = false);
      } catch (e) {
        _showSnack('Could not disable two-step verification.');
      }
      return;
    }

    // Enabling: collect a phone number, send an SMS enrollment code, then
    // confirm it. This requires a real device (SMS + reCAPTCHA) to test.
    final phoneCtrl = TextEditingController();
    String dialCode = '+92';
    final phone = await showDialog<String>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFFFCE4EC),
          title: const Text('Enable Two-Step Verification', style: TextStyle(color: Colors.pink)),
          content: Row(
            children: [
              Container(
                decoration: BoxDecoration(border: Border.all(color: const Color(0xFFF48FB1)), borderRadius: BorderRadius.circular(8)),
                child: CountryCodePicker(
                  onChanged: (country) => setDialogState(() => dialCode = country.dialCode ?? '+92'),
                  initialSelection: 'PK',
                  favorite: const ['+92', 'PK', '+1', 'US', '+44', 'GB', '+91', 'IN'],
                  textStyle: const TextStyle(color: Colors.pink),
                  backgroundColor: const Color(0xFFFCE4EC),
                  dialogBackgroundColor: const Color(0xFFFCE4EC),
                  searchStyle: const TextStyle(color: Colors.pink),
                  dialogTextStyle: const TextStyle(color: Colors.pink),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: phoneCtrl,
                  keyboardType: TextInputType.phone,
                  style: const TextStyle(color: Colors.pink),
                  decoration: const InputDecoration(
                    labelText: 'Phone number',
                    labelStyle: TextStyle(color: const Color(0xFFEC407A)),
                    hintText: '3001234567',
                    hintStyle: TextStyle(color: const Color(0xFFF48FB1)),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            TextButton(
              onPressed: () => Navigator.pop(context, '$dialCode${phoneCtrl.text.trim()}'),
              child: const Text('Send Code', style: TextStyle(color: Colors.pinkAccent)),
            ),
          ],
        ),
      ),
    );
    if (phone == null || phone == dialCode) return;

    try {
      final session = await user.multiFactor.getSession();
      String? verificationId;

      await FirebaseAuth.instance.verifyPhoneNumber(
        multiFactorSession: session,
        phoneNumber: phone,
        verificationCompleted: (_) {},
        verificationFailed: (e) => _showSnack(e.message ?? 'Verification failed.'),
        codeSent: (vId, _) => verificationId = vId,
        codeAutoRetrievalTimeout: (_) {},
      );

      if (verificationId == null) return;
      final smsCode = await _promptForCode();
      if (smsCode == null || smsCode.isEmpty) return;

      final credential = PhoneAuthProvider.credential(verificationId: verificationId!, smsCode: smsCode);
      await user.multiFactor.enroll(PhoneMultiFactorGenerator.getAssertion(credential), displayName: 'Primary phone');

      await FirebaseFirestore.instance.collection('users').doc(user.uid).update({'twoStepEnabled': true});
      setState(() => _twoStepEnabled = true);
      _showSnack('Two-step verification enabled.');
    } catch (e) {
      _showSnack('Could not enable two-step verification.');
    }
  }

  Future<String?> _promptForCode() async {
    final codeCtrl = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFCE4EC),
        title: const Text('Enter SMS Code', style: TextStyle(color: Colors.pink)),
        content: TextField(
          controller: codeCtrl,
          keyboardType: TextInputType.number,
          style: const TextStyle(color: Colors.pink),
          decoration: const InputDecoration(labelText: '6-digit code', labelStyle: TextStyle(color: const Color(0xFFEC407A))),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(context, codeCtrl.text.trim()),
            child: const Text('Confirm', style: TextStyle(color: Colors.pinkAccent)),
          ),
        ],
      ),
    );
  }

  void _showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('Account & Security')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.lock_outline, color: const Color(0xFFD81B60)),
            title: const Text('Change Password', style: TextStyle(color: Colors.pink)),
            trailing: const Icon(Icons.chevron_right, color: const Color(0xFFF06292)),
            onTap: _showChangePasswordDialog,
          ),
          ListTile(
            leading: const Icon(Icons.email_outlined, color: const Color(0xFFD81B60)),
            title: const Text('Change Email', style: TextStyle(color: Colors.pink)),
            trailing: const Icon(Icons.chevron_right, color: const Color(0xFFF06292)),
            onTap: _showChangeEmailDialog,
          ),
          _loadingTwoStep
              ? const Padding(
                  padding: EdgeInsets.all(16),
                  child: Center(child: CircularProgressIndicator()),
                )
              : SwitchListTile(
                  activeColor: Colors.pink,
                  secondary: const Icon(Icons.verified_user_outlined, color: const Color(0xFFD81B60)),
                  title: const Text('Two-Step Verification', style: TextStyle(color: Colors.pink)),
                  subtitle: const Text(
                    'Require an SMS code on new sign-ins',
                    style: TextStyle(color: const Color(0xFFEC407A), fontSize: 12),
                  ),
                  value: _twoStepEnabled,
                  onChanged: _toggleTwoStep,
                ),
        ],
      ),
    );
  }
}
