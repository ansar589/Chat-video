import 'package:flutter/material.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'payment_methods_screen.dart';

class BoostPackage {
  final String id;
  final int coins;
  final String priceLabel;
  final String label;
  const BoostPackage(this.id, this.coins, this.priceLabel, this.label);
}

const List<BoostPackage> boostPackages = [
  BoostPackage('small', 200, '\$4.99', '3-day boost · ~5k extra views'),
  BoostPackage('medium', 500, '\$14.99', '7-day boost · ~15k extra views'),
  BoostPackage('large', 1000, '\$29.99', '14-day boost · ~40k extra views'),
];

class BoostVideoScreen extends StatefulWidget {
  final String videoId;
  const BoostVideoScreen({super.key, required this.videoId});

  @override
  State<BoostVideoScreen> createState() => _BoostVideoScreenState();
}

class _BoostVideoScreenState extends State<BoostVideoScreen> {
  String _platform = 'facebook'; // 'facebook' | 'google'
  String? _selectedPackage;
  String _payWith = 'coins'; // 'coins' | a paymentMethodId
  List<dynamic> _cards = [];
  List<dynamic> _bankAccounts = [];
  bool _loadingMethods = true;
  bool _loading = false;
  String? _error;
  String? _success;

  @override
  void initState() {
    super.initState();
    _loadPaymentMethods();
  }

  Future<void> _loadPaymentMethods() async {
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('listPaymentMethods');
      final result = await callable.call();
      setState(() {
        _cards = result.data['cards'] ?? [];
        _bankAccounts = result.data['bankAccounts'] ?? [];
      });
    } catch (_) {
      // Non-fatal — coins remain available as a fallback.
    } finally {
      if (mounted) setState(() => _loadingMethods = false);
    }
  }

  Future<void> _submitBoost() async {
    if (_selectedPackage == null) {
      setState(() => _error = 'Choose a boost package first.');
      return;
    }
    setState(() { _loading = true; _error = null; _success = null; });

    try {
      final callable = FirebaseFunctions.instance.httpsCallable('requestVideoBoost');
      await callable.call({
        'videoId': widget.videoId,
        'platform': _platform,
        'packageId': _selectedPackage,
        if (_payWith != 'coins') 'paymentMethodId': _payWith,
      });
      setState(() => _success = 'Boost request submitted! It will go live shortly.');
    } catch (e) {
      setState(() => _error = 'Boost failed — check your balance/payment method and try again.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final selectedPkg = boostPackages.firstWhere(
      (p) => p.id == _selectedPackage,
      orElse: () => boostPackages.first,
    );

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('Boost Video')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            const Text('Promote your video on:',
                style: TextStyle(color: const Color(0xFFD81B60), fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _PlatformTile(
                    label: 'Facebook',
                    icon: Icons.facebook,
                    selected: _platform == 'facebook',
                    onTap: () => setState(() => _platform = 'facebook'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _PlatformTile(
                    label: 'Google',
                    icon: Icons.ads_click,
                    selected: _platform == 'google',
                    onTap: () => setState(() => _platform = 'google'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            const Text('Choose a boost package:',
                style: TextStyle(color: const Color(0xFFD81B60), fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...boostPackages.map((pkg) {
              final isSelected = _selectedPackage == pkg.id;
              final contentColor = isSelected ? Colors.white : const Color(0xFFC2185B);
              return Card(
                color: isSelected ? const Color(0xFF880E4F) : const Color(0xFFFCE4EC),
                child: ListTile(
                  title: Text('${pkg.priceLabel}  ·  or ${pkg.coins} coins',
                      style: TextStyle(color: contentColor)),
                  subtitle: Text(pkg.label, style: TextStyle(color: contentColor.withOpacity(0.8))),
                  trailing: isSelected
                      ? Icon(Icons.check_circle, color: contentColor)
                      : null,
                  onTap: () => setState(() => _selectedPackage = pkg.id),
                ),
              );
            }),
            const SizedBox(height: 24),
            const Text('Pay with:', style: TextStyle(color: const Color(0xFFD81B60), fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (_loadingMethods)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: CircularProgressIndicator(),
              )
            else ...[
              RadioListTile<String>(
                value: 'coins',
                groupValue: _payWith,
                activeColor: Colors.pink,
                title: const Text('In-app coins', style: TextStyle(color: Colors.pink)),
                onChanged: (v) => setState(() => _payWith = v!),
              ),
              ..._cards.map((c) => RadioListTile<String>(
                    value: c['id'] as String,
                    groupValue: _payWith,
                    activeColor: Colors.pink,
                    title: Text('${c['brand']} •••• ${c['last4']}',
                        style: const TextStyle(color: Colors.pink)),
                    secondary: const Icon(Icons.credit_card, color: const Color(0xFFEC407A)),
                    onChanged: (v) => setState(() => _payWith = v!),
                  )),
              ..._bankAccounts.map((b) => RadioListTile<String>(
                    value: b['id'] as String,
                    groupValue: _payWith,
                    activeColor: Colors.pink,
                    title: Text('${b['bankName'] ?? 'Bank account'} •••• ${b['last4']}',
                        style: const TextStyle(color: Colors.pink)),
                    secondary: const Icon(Icons.account_balance, color: const Color(0xFFEC407A)),
                    onChanged: (v) => setState(() => _payWith = v!),
                  )),
              TextButton.icon(
                icon: const Icon(Icons.add, color: Colors.pinkAccent),
                label: const Text('Add a card or bank account', style: TextStyle(color: Colors.pinkAccent)),
                onPressed: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const PaymentMethodsScreen()),
                  );
                  _loadPaymentMethods();
                },
              ),
            ],
            const SizedBox(height: 16),
            if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
            if (_success != null) Text(_success!, style: const TextStyle(color: Colors.greenAccent)),
            const SizedBox(height: 16),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
              onPressed: _loading ? null : _submitBoost,
              child: _loading
                  ? const CircularProgressIndicator()
                  : Text(_selectedPackage == null
                      ? 'Boost Now'
                      : 'Boost Now — ${_payWith == 'coins' ? '${selectedPkg.coins} coins' : selectedPkg.priceLabel}'),
            ),
            const SizedBox(height: 8),
            const Text(
              'Boosted videos are promoted as ads on the selected platform. '
              'Delivery and final reach are controlled by that platform and '
              'not guaranteed.',
              style: TextStyle(color: const Color(0xFFF06292), fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlatformTile extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _PlatformTile({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final contentColor = selected ? Colors.white : const Color(0xFFC2185B);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF880E4F) : const Color(0xFFFCE4EC),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: selected ? const Color(0xFF880E4F) : const Color(0xFFF8BBD0)),
        ),
        child: Column(
          children: [
            Icon(icon, color: contentColor),
            const SizedBox(height: 6),
            Text(label, style: TextStyle(color: contentColor)),
          ],
        ),
      ),
    );
  }
}
