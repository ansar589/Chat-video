import 'package:flutter/material.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:url_launcher/url_launcher.dart';

/// Amazon integration.
///
/// "Login with Amazon" opens Amazon's own OAuth page in the browser —
/// this genuinely works once you register a Security Profile at
/// https://developer.amazon.com/loginwithamazon and replace
/// AMAZON_CLIENT_ID below.
///
/// Product search calls the searchAmazonProducts Cloud Function, which
/// requires your own Amazon Associates account + Product Advertising API
/// access (see the TODO in index.js) — until that's configured, search
/// will show a clear "not set up yet" message rather than fake results.
///
/// There is no way to check out inside this app — "Shop on Amazon" opens
/// the real Amazon app/site, which is how every third-party app handles
/// Amazon purchases; Amazon doesn't offer an embeddable checkout.
class AmazonScreen extends StatefulWidget {
  const AmazonScreen({super.key});

  @override
  State<AmazonScreen> createState() => _AmazonScreenState();
}

class _AmazonScreenState extends State<AmazonScreen> {
  static const String amazonClientId = 'YOUR_AMAZON_LWA_CLIENT_ID';
  static const String redirectUri = 'https://your-app-domain.example.com/amazon-callback';

  bool _loggedIn = false;
  final _searchCtrl = TextEditingController();
  bool _searching = false;
  String? _searchError;
  List<dynamic> _results = [];

  Future<void> _loginWithAmazon() async {
    final authUrl = Uri.https('www.amazon.com', '/ap/oa', {
      'client_id': amazonClientId,
      'scope': 'profile',
      'response_type': 'code',
      'redirect_uri': redirectUri,
    });
    final opened = await launchUrl(authUrl, mode: LaunchMode.externalApplication);
    if (opened) {
      // In a full implementation, redirectUri points to a page/Cloud
      // Function that exchanges the auth code for a token and reports
      // back to the app (e.g. via a deep link). That handoff isn't
      // wired up here — see the class doc comment.
      setState(() => _loggedIn = true);
    }
  }

  Future<void> _search() async {
    final query = _searchCtrl.text.trim();
    if (query.isEmpty) return;
    setState(() { _searching = true; _searchError = null; _results = []; });

    try {
      final callable = FirebaseFunctions.instance.httpsCallable('searchAmazonProducts');
      final result = await callable.call({'query': query});
      setState(() => _results = result.data['items'] ?? []);
    } on FirebaseFunctionsException catch (e) {
      setState(() => _searchError = e.code == 'failed-precondition'
          ? 'Amazon product search isn\'t set up yet — see the README.'
          : 'Search failed. Please try again.');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _shopOnAmazon() async {
    await launchUrl(Uri.parse('https://www.amazon.com'), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('Amazon')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            if (!_loggedIn)
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF9900)),
                icon: const Icon(Icons.login, color: Colors.black87),
                label: const Text('Login with Amazon', style: TextStyle(color: Colors.black87)),
                onPressed: _loginWithAmazon,
              )
            else
              Row(
                children: const [
                  Icon(Icons.check_circle, color: Colors.pink),
                  SizedBox(width: 8),
                  Text('Signed in with Amazon', style: TextStyle(color: Colors.pink)),
                ],
              ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    decoration: const InputDecoration(
                      hintText: 'Search Amazon products',
                      prefixIcon: Icon(Icons.search),
                    ),
                    onSubmitted: (_) => _search(),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                  onPressed: _searching ? null : _search,
                  child: _searching
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Search'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (_searchError != null)
              Text(_searchError!, style: const TextStyle(color: Colors.red, fontSize: 13)),
            ..._results.map((item) => ListTile(
                  title: Text(item['title'] ?? ''),
                  subtitle: Text(item['price'] ?? ''),
                )),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              icon: const Icon(Icons.shopping_bag_outlined),
              label: const Text('Shop on Amazon'),
              onPressed: _shopOnAmazon,
            ),
            const SizedBox(height: 12),
            const Text(
              'Checkout always happens on Amazon\'s own app or site — no '
              'third-party app, including this one, can process an Amazon '
              'purchase internally.',
              style: TextStyle(color: Colors.pink, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
