import 'package:flutter/material.dart';
import 'package:cloud_functions/cloud_functions.dart';

class MobilePackage {
  final String id;
  final String label;
  final int coins;
  const MobilePackage(this.id, this.label, this.coins);
}

// Must mirror TELENOR_PACKAGES on the backend.
const List<MobilePackage> telenorPackages = [
  MobilePackage('daily_basic', 'Daily Basic — 300MB + 50 mins', 30),
  MobilePackage('weekly_max', 'Weekly Max — 3GB + 200 mins', 150),
  MobilePackage('monthly_super', 'Monthly Super — 12GB + 1000 mins', 500),
];

class MobilePackagesScreen extends StatefulWidget {
  const MobilePackagesScreen({super.key});

  @override
  State<MobilePackagesScreen> createState() => _MobilePackagesScreenState();
}

class _MobilePackagesScreenState extends State<MobilePackagesScreen> {
  final _phoneCtrl = TextEditingController();
  bool _loading = false;
  String? _message;

  Future<void> _buy(String packageId) async {
    final phone = _phoneCtrl.text.trim();
    if (!RegExp(r'^(\+92|0)3\d{9}$').hasMatch(phone)) {
      setState(() => _message = 'Enter a valid Pakistani mobile number (e.g. 03XXXXXXXXX).');
      return;
    }

    setState(() { _loading = true; _message = null; });
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('purchaseMobilePackage');
      await callable.call({'phoneNumber': phone, 'packageId': packageId});
      setState(() => _message = 'Request submitted for $phone.');
    } catch (e) {
      setState(() => _message = 'Purchase failed — check your coin balance and try again.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('Telenor Packages')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            const Text(
              'Buy Telenor call/SMS/internet bundles using your in-app '
              'coin balance.',
              style: TextStyle(color: const Color(0xFFD81B60), fontSize: 13),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: Colors.pink),
              decoration: const InputDecoration(
                labelText: 'Telenor mobile number',
                labelStyle: TextStyle(color: const Color(0xFFEC407A)),
                hintText: '03XXXXXXXXX',
                hintStyle: TextStyle(color: const Color(0xFFF48FB1)),
                prefixIcon: Icon(Icons.phone_android, color: const Color(0xFFEC407A)),
              ),
            ),
            const SizedBox(height: 16),
            if (_message != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(_message!, style: const TextStyle(color: Colors.pinkAccent)),
              ),
            ...telenorPackages.map((pkg) => Card(
                  color: const Color(0xFFFCE4EC),
                  child: ListTile(
                    leading: const Icon(Icons.sim_card, color: Colors.pink),
                    title: Text(pkg.label, style: const TextStyle(color: Colors.pink, fontSize: 13)),
                    trailing: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                      onPressed: _loading ? null : () => _buy(pkg.id),
                      child: Text('${pkg.coins} coins'),
                    ),
                  ),
                )),
            const SizedBox(height: 12),
            const Text(
              'Real bundle delivery requires a Telenor reseller/aggregator '
              'partnership — see the README for details.',
              style: TextStyle(color: const Color(0xFFF06292), fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}
