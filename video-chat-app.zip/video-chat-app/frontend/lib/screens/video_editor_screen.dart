import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_editor/video_editor.dart';
import 'package:ffmpeg_kit_flutter/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter/return_code.dart';
import 'package:path_provider/path_provider.dart';
import 'video_upload_screen.dart';

/// Available color-grading filters, applied via FFmpeg's `eq`/`colorbalance`
/// filters at export time (same idea as CapCut's filter presets).
class VideoFilter {
  final String name;
  final String ffmpegFilter; // empty string = no filter (original)
  const VideoFilter(this.name, this.ffmpegFilter);
}

const List<VideoFilter> videoFilters = [
  VideoFilter('Original', ''),
  VideoFilter('Vivid', 'eq=saturation=1.6:contrast=1.15'),
  VideoFilter('Warm', 'colorbalance=rs=0.15:gs=0.05:bs=-0.15'),
  VideoFilter('Cool', 'colorbalance=rs=-0.15:gs=0.0:bs=0.2'),
  VideoFilter('B&W', 'hue=s=0'),
  VideoFilter('Moody', 'eq=contrast=1.3:brightness=-0.05:saturation=0.8'),
  VideoFilter('Bright', 'eq=brightness=0.08:contrast=1.05'),
];

class VideoEditorScreenPage extends StatefulWidget {
  final File videoFile;
  const VideoEditorScreenPage({super.key, required this.videoFile});

  @override
  State<VideoEditorScreenPage> createState() => _VideoEditorScreenPageState();
}

class _VideoEditorScreenPageState extends State<VideoEditorScreenPage> {
  late final VideoEditorController _controller;
  int _selectedFilterIndex = 0;
  bool _exporting = false;
  double _exportProgress = 0;

  @override
  void initState() {
    super.initState();
    _controller = VideoEditorController.file(
      widget.videoFile,
      minDuration: const Duration(seconds: 1),
      maxDuration: const Duration(seconds: 90), // cap clip length, like short-video apps
    )..initialize().then((_) => setState(() {}));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// Exports the trimmed range with the chosen filter burned in via FFmpeg,
  /// then hands the final file off to the upload screen.
  Future<void> _exportAndContinue() async {
    setState(() { _exporting = true; _exportProgress = 0; });

    final tempDir = await getTemporaryDirectory();
    final outputPath =
        '${tempDir.path}/edited_${DateTime.now().millisecondsSinceEpoch}.mp4';

    final start = _controller.startTrim.inSeconds;
    final duration = (_controller.endTrim - _controller.startTrim).inSeconds;
    final filter = videoFilters[_selectedFilterIndex].ffmpegFilter;

    final vfArg = filter.isEmpty ? '' : '-vf "$filter"';

    final command =
        '-y -i "${widget.videoFile.path}" -ss $start -t $duration $vfArg '
        '-c:v libx264 -preset veryfast -c:a aac "$outputPath"';

    await FFmpegKit.execute(command).then((session) async {
      final returnCode = await session.getReturnCode();
      setState(() => _exporting = false);

      if (ReturnCode.isSuccess(returnCode) && mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => VideoUploadScreen(editedVideoFile: File(outputPath)),
          ),
        );
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Export failed. Please try again.')),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_controller.initialized) {
      return const Scaffold(
        backgroundColor: Colors.white,
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Edit Video'),
        actions: [
          TextButton(
            onPressed: _exporting ? null : _exportAndContinue,
            child: const Text('Next', style: TextStyle(color: Colors.pinkAccent)),
          ),
        ],
      ),
      body: _exporting
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: Colors.pink),
                  SizedBox(height: 12),
                  Text('Exporting video...', style: TextStyle(color: const Color(0xFFEC407A))),
                ],
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: Center(
                    child: AspectRatio(
                      aspectRatio: _controller.video.value.aspectRatio,
                      child: CropGridViewer.preview(controller: _controller),
                    ),
                  ),
                ),
                // --- Trim bar (drag handles to cut the clip, like CapCut) ---
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                  child: TrimSlider(
                    controller: _controller,
                    height: 60,
                    horizontalMargin: 20,
                  ),
                ),
                // --- Filter strip ---
                SizedBox(
                  height: 90,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    itemCount: videoFilters.length,
                    itemBuilder: (context, i) {
                      final selected = i == _selectedFilterIndex;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedFilterIndex = i),
                        child: Container(
                          width: 64,
                          margin: const EdgeInsets.only(right: 10),
                          child: Column(
                            children: [
                              Container(
                                height: 48,
                                width: 48,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: selected ? Colors.pink : const Color(0xFFF48FB1),
                                    width: selected ? 3 : 1,
                                  ),
                                  color: const Color(0xFFFCE4EC),
                                ),
                                child: const Icon(Icons.filter, color: const Color(0xFFEC407A)),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                videoFilters[i].name,
                                style: TextStyle(
                                  fontSize: 11,
                                  color: selected ? Colors.pinkAccent : const Color(0xFFEC407A),
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
    );
  }
}
