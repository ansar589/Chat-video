import 'package:flutter/material.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:url_launcher/url_launcher.dart';

class NewsScreen extends StatefulWidget {
  const NewsScreen({super.key});

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  bool _loading = true;
  String? _error;
  List<dynamic> _articles = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('latestNews');
      final result = await callable.call({'country': 'pk'});
      setState(() => _articles = result.data['articles'] ?? []);
    } on FirebaseFunctionsException catch (e) {
      setState(() => _error = e.code == 'failed-precondition'
          ? 'News isn\'t set up yet — add a NewsAPI key (see README).'
          : 'Could not load news right now.');
    } catch (e) {
      setState(() => _error = 'Could not load news right now.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('News'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _load)],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.pink)),
                  ),
                )
              : _articles.isEmpty
                  ? const Center(child: Text('No headlines right now', style: TextStyle(color: Colors.pink)))
                  : ListView.builder(
                      itemCount: _articles.length,
                      itemBuilder: (context, i) {
                        final a = _articles[i] as Map<String, dynamic>;
                        return ListTile(
                          leading: a['urlToImage'] != null
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(6),
                                  child: Image.network(a['urlToImage'], width: 64, height: 64, fit: BoxFit.cover),
                                )
                              : const Icon(Icons.article_outlined, color: Colors.pink),
                          title: Text(a['title'] ?? '', maxLines: 2, overflow: TextOverflow.ellipsis),
                          subtitle: Text(a['source']?['name'] ?? '', style: const TextStyle(color: Colors.pink, fontSize: 12)),
                          onTap: () async {
                            final url = a['url'];
                            if (url != null) {
                              await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
                            }
                          },
                        );
                      },
                    ),
    );
  }
}
