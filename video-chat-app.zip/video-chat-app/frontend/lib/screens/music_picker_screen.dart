import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

/// IMPORTANT: Populate this list only with tracks you have proper licensing
/// for — e.g. royalty-free libraries (Epidemic Sound, Artlist, YouTube Audio
/// Library) or independent artists who've granted permission. Using
/// copyrighted commercial songs (Bollywood/Punjabi hits, etc.) without a
/// license exposes the app to takedown and legal liability.
class MusicTrack {
  final String title;
  final String artist;
  final String url;
  const MusicTrack({required this.title, required this.artist, required this.url});
}

const List<MusicTrack> sampleLicensedTracks = [
  MusicTrack(title: 'Upbeat Corporate', artist: 'Royalty Free Library', url: ''),
  MusicTrack(title: 'Chill Lo-fi Beat', artist: 'Royalty Free Library', url: ''),
  MusicTrack(title: 'Energetic Pop', artist: 'Royalty Free Library', url: ''),
];

class MusicPickerScreen extends StatefulWidget {
  const MusicPickerScreen({super.key});

  @override
  State<MusicPickerScreen> createState() => _MusicPickerScreenState();
}

class _MusicPickerScreenState extends State<MusicPickerScreen> {
  final _player = AudioPlayer();
  int? _playingIndex;

  Future<void> _preview(int index) async {
    if (sampleLicensedTracks[index].url.isEmpty) return;
    setState(() => _playingIndex = index);
    await _player.setUrl(sampleLicensedTracks[index].url);
    await _player.play();
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Choose Music')),
      body: ListView.builder(
        itemCount: sampleLicensedTracks.length,
        itemBuilder: (context, i) {
          final track = sampleLicensedTracks[i];
          return ListTile(
            leading: Icon(
              _playingIndex == i ? Icons.pause_circle : Icons.play_circle,
              color: Colors.pink,
            ),
            title: Text(track.title, style: const TextStyle(color: Colors.pink)),
            subtitle: Text(track.artist, style: const TextStyle(color: const Color(0xFFEC407A))),
            onTap: () => _preview(i),
            trailing: TextButton(
              onPressed: () => Navigator.pop(context, track),
              child: const Text('Use', style: TextStyle(color: Colors.pinkAccent)),
            ),
          );
        },
      ),
    );
  }
}
