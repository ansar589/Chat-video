import 'package:flutter/material.dart';
import 'package:cloud_functions/cloud_functions.dart';

class LiveCricketScreen extends StatefulWidget {
  const LiveCricketScreen({super.key});

  @override
  State<LiveCricketScreen> createState() => _LiveCricketScreenState();
}

class _LiveCricketScreenState extends State<LiveCricketScreen> {
  bool _loading = true;
  String? _error;
  List<dynamic> _matches = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('cricketLiveScores');
      final result = await callable.call();
      setState(() => _matches = result.data['matches'] ?? []);
    } on FirebaseFunctionsException catch (e) {
      setState(() => _error = e.code == 'failed-precondition'
          ? 'Live cricket isn\'t set up yet — add a CricAPI key (see README).'
          : 'Could not load scores right now.');
    } catch (e) {
      setState(() => _error = 'Could not load scores right now.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Live Cricket'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _load)],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.pink)),
                  ),
                )
              : _matches.isEmpty
                  ? const Center(child: Text('No live matches right now', style: TextStyle(color: Colors.pink)))
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: _matches.length,
                      itemBuilder: (context, i) {
                        final m = _matches[i] as Map<String, dynamic>;
                        return Card(
                          color: const Color(0xFFFCE4EC),
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(m['name'] ?? 'Match', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.pink)),
                                const SizedBox(height: 6),
                                Text(m['status'] ?? '', style: const TextStyle(color: Colors.pink, fontSize: 13)),
                                if (m['score'] != null) ...[
                                  const SizedBox(height: 8),
                                  ...List<dynamic>.from(m['score']).map((s) => Text(
                                        '${s['inning'] ?? ''}: ${s['r'] ?? 0}/${s['w'] ?? 0} (${s['o'] ?? 0} ov)',
                                        style: const TextStyle(color: Colors.pink, fontSize: 13),
                                      )),
                                ],
                              ],
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}
