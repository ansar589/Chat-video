import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'video_editor_screen.dart';

/// Entry point: user picks a video from their gallery/camera, then is sent
/// to the CapCut-style editor (trim + filters) before it's uploaded.
class PickVideoScreen extends StatelessWidget {
  const PickVideoScreen({super.key});

  Future<void> _pickAndEdit(BuildContext context, ImageSource source) async {
    final picker = ImagePicker();
    final picked = await picker.pickVideo(source: source, maxDuration: const Duration(minutes: 3));
    if (picked == null) return;
    if (!context.mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => VideoEditorScreenPage(videoFile: File(picked.path)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('New Video')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
              icon: const Icon(Icons.video_library),
              label: const Text('Choose from Gallery'),
              onPressed: () => _pickAndEdit(context, ImageSource.gallery),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              icon: const Icon(Icons.videocam, color: Colors.pink),
              label: const Text('Record New Video', style: TextStyle(color: Colors.pink)),
              onPressed: () => _pickAndEdit(context, ImageSource.camera),
            ),
          ],
        ),
      ),
    );
  }
}

/// Final step: caption + upload the edited video to Firebase Storage,
/// then create its Firestore document so it shows up in the feed.
class VideoUploadScreen extends StatefulWidget {
  final File editedVideoFile;
  const VideoUploadScreen({super.key, required this.editedVideoFile});

  @override
  State<VideoUploadScreen> createState() => _VideoUploadScreenState();
}

class _VideoUploadScreenState extends State<VideoUploadScreen> {
  final _captionCtrl = TextEditingController();
  final _hashtagCtrl = TextEditingController();
  final List<String> _hashtags = [];
  String _visibility = 'public'; // public | private | adult
  bool _uploading = false;
  double _progress = 0;

  void _addHashtag(String raw) {
    var tag = raw.trim().replaceAll('#', '').replaceAll(' ', '');
    if (tag.isEmpty) return;
    if (_hashtags.length >= 10) return; // reasonable cap
    if (!_hashtags.contains(tag)) {
      setState(() => _hashtags.add(tag));
    }
    _hashtagCtrl.clear();
  }

  Future<bool> _confirmAdultUpload() async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: const Color(0xFFFCE4EC),
            title: const Text('Mark as Adult (18+) Content', style: TextStyle(color: Colors.pink)),
            content: const Text(
              'This video will only be shown to users who have confirmed they '
              'are 18 or older, and will be excluded from the general feed, '
              'search, and recommendations. Confirm this video contains '
              'adult/mature content?',
              style: TextStyle(color: const Color(0xFFD81B60)),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel', style: TextStyle(color: const Color(0xFFEC407A))),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Confirm', style: TextStyle(color: Colors.pinkAccent)),
              ),
            ],
          ),
        ) ??
        false;
  }

  Future<void> _upload() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    if (_visibility == 'adult') {
      final confirmed = await _confirmAdultUpload();
      if (!confirmed) return;
    }

    setState(() { _uploading = true; _progress = 0; });

    final fileName = 'videos/$uid/${DateTime.now().millisecondsSinceEpoch}.mp4';
    final ref = FirebaseStorage.instance.ref(fileName);
    final uploadTask = ref.putFile(widget.editedVideoFile);

    uploadTask.snapshotEvents.listen((snapshot) {
      setState(() {
        _progress = snapshot.bytesTransferred / snapshot.totalBytes;
      });
    });

    await uploadTask;
    final downloadUrl = await ref.getDownloadURL();

    await FirebaseFirestore.instance.collection('videos').add({
      'ownerId': uid,
      'videoUrl': downloadUrl,
      'caption': _captionCtrl.text.trim(),
      'hashtags': _hashtags,
      'visibility': _visibility, // 'public' | 'private' | 'adult'
      'isAdult': _visibility == 'adult',
      'likes': 0,
      'createdAt': FieldValue.serverTimestamp(),
    });

    setState(() => _uploading = false);
    if (mounted) Navigator.popUntil(context, (route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('Post Video')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              controller: _captionCtrl,
              style: const TextStyle(color: Colors.pink),
              decoration: const InputDecoration(
                labelText: 'Write a caption...',
                labelStyle: TextStyle(color: const Color(0xFFEC407A)),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 20),

            // --- Hashtags ---
            const Text('Hashtags', style: TextStyle(color: const Color(0xFFD81B60), fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: _hashtags
                  .map((tag) => Chip(
                        label: Text('#$tag', style: const TextStyle(color: Colors.white)),
                        backgroundColor: const Color(0xFFC2185B),
                        deleteIcon: const Icon(Icons.close, size: 16, color: Colors.white),
                        onDeleted: () => setState(() => _hashtags.remove(tag)),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _hashtagCtrl,
              style: const TextStyle(color: Colors.pink),
              decoration: const InputDecoration(
                hintText: 'Add a hashtag and press enter',
                hintStyle: TextStyle(color: const Color(0xFFF06292)),
                prefixIcon: Icon(Icons.tag, color: const Color(0xFFEC407A)),
              ),
              onSubmitted: _addHashtag,
            ),
            const SizedBox(height: 24),

            // --- Visibility ---
            const Text('Who can see this video?',
                style: TextStyle(color: const Color(0xFFD81B60), fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            RadioListTile<String>(
              value: 'public',
              groupValue: _visibility,
              activeColor: Colors.pink,
              title: const Text('Public', style: TextStyle(color: Colors.pink)),
              subtitle: const Text('Visible to everyone in the feed and search',
                  style: TextStyle(color: const Color(0xFFF06292), fontSize: 12)),
              onChanged: (v) => setState(() => _visibility = v!),
            ),
            RadioListTile<String>(
              value: 'private',
              groupValue: _visibility,
              activeColor: Colors.pink,
              title: const Text('Private', style: TextStyle(color: Colors.pink)),
              subtitle: const Text('Only visible to you',
                  style: TextStyle(color: const Color(0xFFF06292), fontSize: 12)),
              onChanged: (v) => setState(() => _visibility = v!),
            ),
            RadioListTile<String>(
              value: 'adult',
              groupValue: _visibility,
              activeColor: Colors.pink,
              title: const Text('Adult (18+)', style: TextStyle(color: Colors.pink)),
              subtitle: const Text('Age-gated — hidden from the general feed and from users who have not confirmed they are 18+',
                  style: TextStyle(color: const Color(0xFFF06292), fontSize: 12)),
              onChanged: (v) => setState(() => _visibility = v!),
            ),
            const SizedBox(height: 24),

            if (_uploading) ...[
              LinearProgressIndicator(value: _progress, color: Colors.pink),
              const SizedBox(height: 8),
              Text('${(_progress * 100).toStringAsFixed(0)}%',
                  style: const TextStyle(color: const Color(0xFFEC407A))),
            ] else
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                onPressed: _upload,
                child: const Text('Post'),
              ),
          ],
        ),
      ),
    );
  }
}
