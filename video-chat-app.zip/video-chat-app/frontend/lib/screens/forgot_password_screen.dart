import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _emailCtrl = TextEditingController();
  bool _loading = false;
  String? _error;
  bool _sent = false;

  Future<void> _sendResetEmail() async {
    if (_emailCtrl.text.trim().isEmpty) {
      setState(() => _error = 'Enter your email address.');
      return;
    }
    setState(() { _loading = true; _error = null; });
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: _emailCtrl.text.trim());
      setState(() => _sent = true);
    } on FirebaseAuthException catch (e) {
      setState(() => _error = e.message ?? 'Could not send reset email.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reset Password')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_sent) ...[
                const Icon(Icons.mark_email_read, color: Colors.pink, size: 48),
                const SizedBox(height: 16),
                const Text(
                  'Check your inbox for a link to reset your password.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: const Color(0xFFD81B60)),
                ),
                const SizedBox(height: 20),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Back to Sign In', style: TextStyle(color: Colors.pinkAccent)),
                ),
              ] else ...[
                const Text(
                  'Enter the email associated with your account and we\'ll send a link to reset your password.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: const Color(0xFFD81B60)),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  style: const TextStyle(color: Colors.pink),
                  decoration: const InputDecoration(labelText: 'Email', labelStyle: TextStyle(color: const Color(0xFFEC407A))),
                ),
                const SizedBox(height: 16),
                if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _loading ? null : _sendResetEmail,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                  child: _loading ? const CircularProgressIndicator() : const Text('Send Reset Link'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
