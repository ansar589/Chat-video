import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'edit_profile_screen.dart';
import 'account_security_screen.dart';
import 'switch_account_screen.dart';
import 'payment_methods_screen.dart';
import 'monetization_screen.dart';
import 'prayer_times_screen.dart';
import 'mobile_packages_screen.dart';
import '../models/user_model.dart';
import 'amazon_screen.dart';
import 'live_cricket_screen.dart';
import 'news_screen.dart';

class SettingsScreen extends StatelessWidget {
  final AppUser user;
  const SettingsScreen({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('Settings')),
      body: ListView(
        children: [
          _sectionHeader('Account'),
          _tile(context, Icons.person_outline, 'Edit Profile',
              () => EditProfileScreen(user: user)),
          _tile(context, Icons.security, 'Account & Security',
              () => const AccountSecurityScreen()),
          _tile(context, Icons.switch_account, 'Switch / Add Account',
              () => const SwitchAccountScreen()),

          _sectionHeader('Payments & Earnings'),
          _tile(context, Icons.account_balance, 'Payment Methods (Card/Bank)',
              () => const PaymentMethodsScreen()),
          _tile(context, Icons.trending_up, 'Monetization & Earnings',
              () => const MonetizationScreen()),

          _sectionHeader('More'),
          _tile(context, Icons.mosque, 'Namaz Timings',
              () => const PrayerTimesScreen()),
          _tile(context, Icons.sim_card, 'Telenor Packages',
              () => const MobilePackagesScreen()),
          _tile(context, Icons.shopping_bag_outlined, 'Amazon Shopping',
              () => const AmazonScreen()),
          _tile(context, Icons.sports_cricket, 'Live Cricket',
              () => const LiveCricketScreen()),
          _tile(context, Icons.article_outlined, 'News',
              () => const NewsScreen()),

          _sectionHeader(''),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text('Sign Out', style: TextStyle(color: Colors.red)),
            onTap: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  backgroundColor: const Color(0xFFFCE4EC),
                  title: const Text('Sign out?', style: TextStyle(color: Colors.pink)),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sign Out')),
                  ],
                ),
              );
              if (confirm == true) await AuthService().signOut();
            },
          ),
        ],
      ),
    );
  }

  Widget _sectionHeader(String title) {
    if (title.isEmpty) return const SizedBox(height: 12);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      child: Text(title, style: const TextStyle(color: const Color(0xFFEC407A), fontSize: 12, fontWeight: FontWeight.bold)),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String label, Widget Function() builder) {
    return ListTile(
      leading: Icon(icon, color: const Color(0xFFD81B60)),
      title: Text(label, style: const TextStyle(color: Colors.pink)),
      trailing: const Icon(Icons.chevron_right, color: const Color(0xFFF06292)),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => builder())),
    );
  }
}
