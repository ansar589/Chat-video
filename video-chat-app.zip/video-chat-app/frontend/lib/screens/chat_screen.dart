import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'chat_list_screen.dart';

class ChatScreen extends StatefulWidget {
  final String chatId;
  final String otherUid;
  final String otherName;
  const ChatScreen({super.key, required this.chatId, required this.otherUid, required this.otherName});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _textCtrl = TextEditingController();
  final _recorder = AudioRecorder();
  bool _recording = false;
  bool _sending = false;
  String? _quotaError;

  /// Checks the free-message quota (10 free, then referral-earned, then
  /// paid) via the existing consumeFreeMessage Cloud Function before any
  /// message — text, voice, image, or video — is written.
  Future<bool> _checkQuota() async {
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('consumeFreeMessage');
      final result = await callable.call();
      final allowed = result.data['allowed'] as bool;
      if (!allowed) {
        setState(() => _quotaError =
            'No free messages left. Invite friends for more, or unlock via in-app purchase.');
      }
      return allowed;
    } catch (e) {
      setState(() => _quotaError = 'Could not verify message quota.');
      return false;
    }
  }

  Future<void> _ensureChatDocExists() async {
    final myUid = FirebaseAuth.instance.currentUser!.uid;
    final myName = FirebaseAuth.instance.currentUser!.displayName ?? 'User';
    final chatRef = FirebaseFirestore.instance.collection('chats').doc(widget.chatId);
    final doc = await chatRef.get();
    if (!doc.exists) {
      await chatRef.set({
        'participants': [myUid, widget.otherUid],
        'participantNames': {myUid: myName, widget.otherUid: widget.otherName},
        'lastMessage': '',
        'lastMessageType': 'text',
        'lastMessageAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Future<void> _sendMessage({
    required String type,
    String? text,
    String? mediaUrl,
    int? durationSeconds,
  }) async {
    final myUid = FirebaseAuth.instance.currentUser!.uid;
    await _ensureChatDocExists();

    final chatRef = FirebaseFirestore.instance.collection('chats').doc(widget.chatId);
    await chatRef.collection('messages').add({
      'senderId': myUid,
      'type': type,
      'text': text,
      'mediaUrl': mediaUrl,
      'durationSeconds': durationSeconds,
      'createdAt': FieldValue.serverTimestamp(),
    });

    await chatRef.update({
      'lastMessage': text ?? '',
      'lastMessageType': type,
      'lastMessageAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> _sendText() async {
    final text = _textCtrl.text.trim();
    if (text.isEmpty) return;
    setState(() { _sending = true; _quotaError = null; });

    if (await _checkQuota()) {
      await _sendMessage(type: 'text', text: text);
      _textCtrl.clear();
    }
    setState(() => _sending = false);
  }

  Future<void> _pickAndSendMedia(ImageSource source, {required bool isVideo}) async {
    setState(() { _sending = true; _quotaError = null; });
    if (!await _checkQuota()) {
      setState(() => _sending = false);
      return;
    }

    final picker = ImagePicker();
    final picked = isVideo
        ? await picker.pickVideo(source: source, maxDuration: const Duration(minutes: 2))
        : await picker.pickImage(source: source, imageQuality: 85);

    if (picked == null) {
      setState(() => _sending = false);
      return;
    }

    final myUid = FirebaseAuth.instance.currentUser!.uid;
    final ext = isVideo ? 'mp4' : 'jpg';
    final ref = FirebaseStorage.instance
        .ref('chat_media/${widget.chatId}/${myUid}_${DateTime.now().millisecondsSinceEpoch}.$ext');
    await ref.putFile(File(picked.path));
    final url = await ref.getDownloadURL();

    await _sendMessage(type: isVideo ? 'video' : 'image', mediaUrl: url);
    setState(() => _sending = false);
  }

  Future<void> _startRecording() async {
    if (!await _recorder.hasPermission()) return;
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _recorder.start(const RecordConfig(), path: path);
    setState(() => _recording = true);
  }

  Future<void> _stopRecordingAndSend() async {
    final path = await _recorder.stop();
    setState(() => _recording = false);
    if (path == null) return;

    setState(() { _sending = true; _quotaError = null; });
    if (!await _checkQuota()) {
      setState(() => _sending = false);
      return;
    }

    final myUid = FirebaseAuth.instance.currentUser!.uid;
    final ref = FirebaseStorage.instance
        .ref('chat_media/${widget.chatId}/${myUid}_${DateTime.now().millisecondsSinceEpoch}.m4a');
    await ref.putFile(File(path));
    final url = await ref.getDownloadURL();

    await _sendMessage(type: 'voice', mediaUrl: url);
    setState(() => _sending = false);
  }

  void _showAttachSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFFFCE4EC),
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo, color: Colors.pink),
              title: const Text('Photo from gallery', style: TextStyle(color: Colors.pink)),
              onTap: () {
                Navigator.pop(context);
                _pickAndSendMedia(ImageSource.gallery, isVideo: false);
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Colors.pink),
              title: const Text('Take a photo', style: TextStyle(color: Colors.pink)),
              onTap: () {
                Navigator.pop(context);
                _pickAndSendMedia(ImageSource.camera, isVideo: false);
              },
            ),
            ListTile(
              leading: const Icon(Icons.videocam, color: Colors.pink),
              title: const Text('Video from gallery', style: TextStyle(color: Colors.pink)),
              onTap: () {
                Navigator.pop(context);
                _pickAndSendMedia(ImageSource.gallery, isVideo: true);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _recorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final myUid = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: Text(widget.otherName)),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('chats')
                  .doc(widget.chatId)
                  .collection('messages')
                  .orderBy('createdAt', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final docs = snapshot.data!.docs;
                return ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.all(12),
                  itemCount: docs.length,
                  itemBuilder: (context, i) {
                    final data = docs[i].data() as Map<String, dynamic>;
                    final isMe = data['senderId'] == myUid;
                    return MessageBubble(data: data, isMe: isMe);
                  },
                );
              },
            ),
          ),
          if (_quotaError != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(_quotaError!, style: const TextStyle(color: Colors.red, fontSize: 12)),
            ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.attach_file, color: const Color(0xFFD81B60)),
                    onPressed: _sending ? null : _showAttachSheet,
                  ),
                  Expanded(
                    child: TextField(
                      controller: _textCtrl,
                      style: const TextStyle(color: Colors.pink),
                      decoration: const InputDecoration(
                        hintText: 'Message',
                        hintStyle: TextStyle(color: const Color(0xFFF06292)),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onLongPressStart: (_) => _startRecording(),
                    onLongPressEnd: (_) => _stopRecordingAndSend(),
                    child: CircleAvatar(
                      backgroundColor: _recording ? Colors.red : Colors.pink,
                      child: Icon(_recording ? Icons.mic : Icons.mic_none, color: Colors.white, size: 20),
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton(
                    icon: const Icon(Icons.send, color: Colors.pink),
                    onPressed: _sending ? null : _sendText,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class MessageBubble extends StatefulWidget {
  final Map<String, dynamic> data;
  final bool isMe;
  const MessageBubble({super.key, required this.data, required this.isMe});

  @override
  State<MessageBubble> createState() => _MessageBubbleState();
}

class _MessageBubbleState extends State<MessageBubble> {
  final _player = AudioPlayer();
  bool _playing = false;

  Future<void> _toggleVoicePlayback() async {
    if (_playing) {
      await _player.pause();
      setState(() => _playing = false);
    } else {
      await _player.setUrl(widget.data['mediaUrl']);
      await _player.play();
      setState(() => _playing = true);
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final type = widget.data['type'] ?? 'text';
    final bubbleColor = widget.isMe ? const Color(0xFFC2185B) : const Color(0xFFFCE4EC);
    final contentColor = widget.isMe ? Colors.white : const Color(0xFFC2185B);

    Widget content;
    switch (type) {
      case 'voice':
        content = Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(_playing ? Icons.pause_circle : Icons.play_circle, color: contentColor),
              onPressed: _toggleVoicePlayback,
            ),
            Text('Voice message', style: TextStyle(color: contentColor)),
          ],
        );
        break;
      case 'image':
        content = ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.network(widget.data['mediaUrl'], width: 180, fit: BoxFit.cover),
        );
        break;
      case 'video':
        content = Container(
          width: 180,
          height: 120,
          decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(8)),
          child: const Center(child: Icon(Icons.play_circle_fill, color: Colors.white, size: 40)),
        );
        break;
      default:
        content = Text(widget.data['text'] ?? '', style: TextStyle(color: contentColor));
    }

    return Align(
      alignment: widget.isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(color: bubbleColor, borderRadius: BorderRadius.circular(14)),
        child: content,
      ),
    );
  }
}
