import 'package:flutter/material.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:url_launcher/url_launcher.dart';

/// Creator monetization dashboard. Requirements are intentionally much
/// lower than Facebook's in-stream ads program (which needs ~10,000
/// followers + 600,000 watch-minutes in the last 60 days, plus a Page
/// review). Here it's just 100 followers + 1,000 total views.
class MonetizationScreen extends StatefulWidget {
  const MonetizationScreen({super.key});

  @override
  State<MonetizationScreen> createState() => _MonetizationScreenState();
}

class _MonetizationScreenState extends State<MonetizationScreen> {
  Map<String, dynamic>? _stats;
  bool _loading = true;
  bool _acting = false;
  String? _message;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    setState(() => _loading = true);
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('getCreatorStats');
      final result = await callable.call();
      setState(() => _stats = Map<String, dynamic>.from(result.data));
    } catch (e) {
      setState(() => _message = 'Could not load your stats.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _setUpPayouts() async {
    setState(() { _acting = true; _message = null; });
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('createPayoutOnboardingLink');
      final result = await callable.call({
        'returnUrl': 'https://example.com/return',
        'refreshUrl': 'https://example.com/reauth',
      });
      final url = result.data['url'] as String;
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (e) {
      setState(() => _message = 'Could not start payout setup.');
    } finally {
      if (mounted) setState(() => _acting = false);
    }
  }

  Future<void> _requestPayout() async {
    setState(() { _acting = true; _message = null; });
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('requestPayout');
      final result = await callable.call();
      final cents = result.data['amountCents'] as int;
      setState(() => _message = 'Payout sent: \$${(cents / 100).toStringAsFixed(2)}');
      await _loadStats();
    } catch (e) {
      setState(() => _message = 'Payout failed — check eligibility and payout setup below.');
    } finally {
      if (mounted) setState(() => _acting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('Monetization')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: ListView(
                children: [
                  Card(
                    color: const Color(0xFFFCE4EC),
                    child: const Padding(
                      padding: EdgeInsets.all(16),
                      child: Text(
                        'Requirements: 100 followers + 1,000 total views.\n'
                        'For comparison, Facebook\'s in-stream ads program '
                        'requires ~10,000 followers and 600,000 watch-minutes '
                        'in the last 60 days — this is a much lower bar.',
                        style: TextStyle(color: const Color(0xFFD81B60), fontSize: 13),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _stat('Followers', '${_stats?['followers'] ?? 0} / ${_stats?['minFollowersRequired'] ?? 100}'),
                  _stat('Total Views', '${_stats?['totalViews'] ?? 0} / ${_stats?['minViewsRequired'] ?? 1000}'),
                  _stat('Eligible', (_stats?['eligible'] ?? false) ? 'Yes' : 'Not yet'),
                  _stat('Pending Earnings',
                      '\$${(((_stats?['pendingEarningsCents'] ?? 0) as int) / 100).toStringAsFixed(2)}'),
                  _stat('Payout Account', (_stats?['payoutAccountReady'] ?? false) ? 'Ready' : 'Not set up'),
                  const SizedBox(height: 20),
                  if (_message != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(_message!, style: const TextStyle(color: Colors.pinkAccent)),
                    ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                    icon: const Icon(Icons.account_balance),
                    label: Text((_stats?['payoutAccountReady'] ?? false)
                        ? 'Manage Payout Account'
                        : 'Set Up Payouts (bank account/card)'),
                    onPressed: _acting ? null : _setUpPayouts,
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.attach_money, color: Colors.pink),
                    label: const Text('Request Payout', style: TextStyle(color: Colors.pink)),
                    onPressed: _acting ? null : _requestPayout,
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Payouts are sent via Stripe to your linked bank account or '
                    'debit card. Stripe handles identity verification during '
                    'setup — we never collect or store your bank/card details.',
                    style: TextStyle(color: const Color(0xFFF06292), fontSize: 11),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _stat(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: const Color(0xFFEC407A))),
          Text(value, style: const TextStyle(color: Colors.pink, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
