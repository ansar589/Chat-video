import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'account_store.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  Future<UserCredential> signUpWithEmail({
    required String email,
    required String password,
    required String displayName,
    required String username,
    required String firstName,
    required String lastName,
    required DateTime dateOfBirth,
    String? phoneNumber,
    String? referralCode,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
    await _createProfile(
      displayName: displayName,
      referralCode: referralCode,
      username: username,
      firstName: firstName,
      lastName: lastName,
      dateOfBirth: dateOfBirth.toIso8601String().split('T').first,
      phoneNumber: phoneNumber,
    );
    await AccountStore.remember(uid: cred.user!.uid, email: email, displayName: displayName);
    return cred;
  }

  Future<UserCredential> signInWithEmail(String email, String password) async {
    final cred = await _auth.signInWithEmailAndPassword(email: email, password: password);
    await AccountStore.remember(
      uid: cred.user!.uid,
      email: email,
      displayName: cred.user!.displayName ?? email,
    );
    return cred;
  }

  Future<UserCredential?> signInWithGoogle(String? referralCode) async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return null;

    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    final userCred = await _auth.signInWithCredential(credential);

    if (userCred.additionalUserInfo?.isNewUser ?? false) {
      // Google sign-up doesn't collect username/DOB/phone upfront — those
      // get auto-generated defaults on the backend, and the user can fill
      // them in later from Edit Profile.
      await _createProfile(displayName: googleUser.displayName ?? 'New User', referralCode: referralCode);
    }
    await AccountStore.remember(
      uid: userCred.user!.uid,
      email: userCred.user!.email ?? '',
      displayName: userCred.user!.displayName ?? 'User',
    );
    return userCred;
  }

  /// Send OTP to a phone number. Returns verificationId via callback.
  Future<void> sendPhoneOtp({
    required String phoneNumber,
    required void Function(String verificationId) onCodeSent,
    required void Function(String error) onFailed,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (FirebaseAuthException e) {
        onFailed(e.message ?? 'Verification failed');
      },
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  Future<UserCredential> confirmPhoneOtp(
      String verificationId, String smsCode, String displayName, String? referralCode) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    final userCred = await _auth.signInWithCredential(credential);
    if (userCred.additionalUserInfo?.isNewUser ?? false) {
      await _createProfile(
        displayName: displayName,
        referralCode: referralCode,
        phoneNumber: userCred.user?.phoneNumber,
      );
    }
    await AccountStore.remember(
      uid: userCred.user!.uid,
      email: userCred.user!.email ?? userCred.user!.phoneNumber ?? '',
      displayName: displayName,
    );
    return userCred;
  }

  Future<void> _createProfile({
    required String displayName,
    String? referralCode,
    String? username,
    String? firstName,
    String? lastName,
    String? dateOfBirth,
    String? phoneNumber,
  }) async {
    final callable = FirebaseFunctions.instance.httpsCallable('createUserProfile');
    await callable.call({
      'displayName': displayName,
      'referredByCode': referralCode,
      'username': username,
      'firstName': firstName,
      'lastName': lastName,
      'dateOfBirth': dateOfBirth,
      'phoneNumber': phoneNumber,
    });
  }

  /// Signs out of the CURRENT account only — used by the account switcher's
  /// "Add another account" flow, which returns to the sign-in screen while
  /// keeping the previous account in the remembered-accounts list so it's
  /// one tap away (still requires re-entering its password — this app
  /// doesn't keep multiple sessions truly live at once, see README).
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }
}
