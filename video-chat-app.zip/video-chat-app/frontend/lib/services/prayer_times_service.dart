import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;

class PrayerTime {
  final String name;
  final String time; // "HH:mm" 24-hour, as returned by the API
  const PrayerTime(this.name, this.time);
}

/// Fetches daily prayer (Namaz) times from the free Aladhan API and
/// schedules local popup notifications at each prayer time.
///
/// Aladhan API docs: https://aladhan.com/prayer-times-api
/// Default city/country is Lahore, Pakistan (this app's base location);
/// pass a different city/country for other users.
class PrayerTimesService {
  static final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    tz_data.initializeTimeZones();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    await _notifications.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
    );
  }

  /// Fetches today's five daily prayer times for the given city/country
  /// using the Muslim World League calculation method (method=3, a common
  /// default — the Aladhan API supports several other methods/schools).
  static Future<List<PrayerTime>> fetchToday({
    String city = 'Lahore',
    String country = 'Pakistan',
  }) async {
    final uri = Uri.parse(
      'https://api.aladhan.com/v1/timingsByCity'
      '?city=$city&country=$country&method=3',
    );
    final response = await http.get(uri);
    if (response.statusCode != 200) {
      throw Exception('Failed to fetch prayer times');
    }
    final data = jsonDecode(response.body);
    final timings = data['data']['timings'] as Map<String, dynamic>;

    // Only the five daily prayers — the API also returns Sunrise/Sunset/
    // Midnight etc., which we don't need for reminders.
    const order = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    return order.map((name) => PrayerTime(name, timings[name])).toList();
  }

  /// Schedules a local popup notification for each prayer time today.
  /// Call this once per day (e.g. on app open, or via a daily background
  /// task) after fetching today's timings.
  static Future<void> scheduleNotifications(List<PrayerTime> prayers) async {
    await _notifications.cancelAll();

    const androidDetails = AndroidNotificationDetails(
      'namaz_reminders',
      'Namaz Reminders',
      channelDescription: 'Popup reminders for daily prayer times',
      importance: Importance.max,
      priority: Priority.high,
      fullScreenIntent: true, // shows as a popup even if the phone is locked
    );
    const details = NotificationDetails(
      android: androidDetails,
      iOS: DarwinNotificationDetails(presentAlert: true, presentSound: true),
    );

    final now = DateTime.now();
    for (var i = 0; i < prayers.length; i++) {
      final parts = prayers[i].time.split(':');
      final hour = int.parse(parts[0]);
      final minute = int.parse(parts[1]);
      var scheduled = DateTime(now.year, now.month, now.day, hour, minute);
      if (scheduled.isBefore(now)) continue; // skip prayers already passed today

      await _notifications.zonedSchedule(
        1000 + i,
        '${prayers[i].name} — Namaz Time',
        'It\'s time for ${prayers[i].name} prayer.',
        tz.TZDateTime.from(scheduled, tz.local),
        details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UiLocalNotificationDateInterpretation.absoluteTime,
      );
    }
  }
}
