import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Remembers accounts previously signed into on this device, so "Add
/// another account" / "Switch account" can show a quick-pick list.
///
/// This does NOT keep multiple Firebase sessions simultaneously live —
/// switching to a remembered account still requires re-entering its
/// password (or redoing Google/phone sign-in). True simultaneous
/// multi-account sessions (like Gmail) would need a secondary FirebaseApp
/// instance per account, which is a bigger change — see README.
class RememberedAccount {
  final String uid;
  final String email;
  final String displayName;
  const RememberedAccount({required this.uid, required this.email, required this.displayName});

  Map<String, dynamic> toJson() => {'uid': uid, 'email': email, 'displayName': displayName};
  factory RememberedAccount.fromJson(Map<String, dynamic> json) => RememberedAccount(
        uid: json['uid'],
        email: json['email'],
        displayName: json['displayName'],
      );
}

class AccountStore {
  static const _key = 'remembered_accounts';

  static Future<void> remember({
    required String uid,
    required String email,
    required String displayName,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final list = await getAll();
    list.removeWhere((a) => a.uid == uid);
    list.insert(0, RememberedAccount(uid: uid, email: email, displayName: displayName));
    final trimmed = list.take(5).toList(); // keep the 5 most recent
    await prefs.setString(_key, jsonEncode(trimmed.map((a) => a.toJson()).toList()));
  }

  static Future<List<RememberedAccount>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    return list.map(RememberedAccount.fromJson).toList();
  }

  static Future<void> forget(String uid) async {
    final prefs = await SharedPreferences.getInstance();
    final list = await getAll();
    list.removeWhere((a) => a.uid == uid);
    await prefs.setString(_key, jsonEncode(list.map((a) => a.toJson()).toList()));
  }
}
