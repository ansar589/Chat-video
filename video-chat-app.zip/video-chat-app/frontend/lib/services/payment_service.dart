import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter_stripe/flutter_stripe.dart';

/// Handles card payments end-to-end.
///
/// IMPORTANT: This class never touches a raw card number. The card form
/// (see payment_screen.dart) uses Stripe's own CardField widget, which
/// sends card details straight to Stripe's servers over TLS. Our backend
/// only ever sees a PaymentIntent id/clientSecret — never the PAN, CVV,
/// or expiry.
class PaymentService {
  /// packageId must match a key in COIN_PACKAGES on the backend
  /// (e.g. 'small', 'medium', 'large').
  Future<void> buyCoins(String packageId) async {
    final callable = FirebaseFunctions.instance.httpsCallable('createPaymentIntent');
    final result = await callable.call({'packageId': packageId});
    final clientSecret = result.data['clientSecret'] as String;

    await Stripe.instance.initPaymentSheet(
      paymentSheetParameters: SetupPaymentSheetParameters(
        paymentIntentClientSecret: clientSecret,
        merchantDisplayName: 'Video Chat App',
        // Allows Apple Pay / Google Pay alongside manual card entry, if configured.
      ),
    );

    // Presents Stripe's own secure card entry UI. Coins are credited by the
    // stripeWebhook Cloud Function once payment actually succeeds —
    // not from this client call — so a modified app can't grant free coins.
    await Stripe.instance.presentPaymentSheet();
  }
}
