import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'screens/signin_screen.dart';
import 'screens/home_feed_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'services/prayer_times_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  // Use your Stripe PUBLISHABLE key here (safe to embed in the app).
  // Never put your Stripe SECRET key in the frontend — that stays in
  // Cloud Functions config only.
  Stripe.publishableKey = 'pk_test_REPLACE_WITH_YOUR_KEY';
  await Stripe.instance.applySettings();

  await PrayerTimesService.init();

  runApp(const VideoChatApp());
}

class VideoChatApp extends StatelessWidget {
  const VideoChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Video Chat App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.pink,
        scaffoldBackgroundColor: Colors.white,
        useMaterial3: true,
      ),
      home: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          if (snapshot.hasData) {
            return const HomeFeedScreen();
          }
          return const SignInScreen();
        },
      ),
    );
  }
}
