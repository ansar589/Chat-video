class AppUser {
  final String uid;
  final String displayName;
  final String referralCode;
  final int referralCount;
  final String level;
  final int freeMessagesRemaining;
  final int followers;
  final bool liveEnabled;
  final int coinBalance;
  final String? photoUrl;
  final String bio;
  final Map<String, String> socialLinks; // keys: youtube, whatsapp, facebook, telegram, discord
  final String username;
  final String firstName;
  final String lastName;
  final String? dateOfBirth; // ISO date string
  final String? phoneNumber;
  final bool twoStepEnabled;

  AppUser({
    required this.uid,
    required this.displayName,
    required this.referralCode,
    required this.referralCount,
    required this.level,
    required this.freeMessagesRemaining,
    required this.followers,
    required this.liveEnabled,
    required this.coinBalance,
    this.photoUrl,
    this.bio = '',
    this.socialLinks = const {},
    this.username = '',
    this.firstName = '',
    this.lastName = '',
    this.dateOfBirth,
    this.phoneNumber,
    this.twoStepEnabled = false,
  });

  factory AppUser.fromMap(String uid, Map<String, dynamic> data) {
    return AppUser(
      uid: uid,
      displayName: data['displayName'] ?? '',
      referralCode: data['referralCode'] ?? '',
      referralCount: data['referralCount'] ?? 0,
      level: data['level'] ?? 'None',
      freeMessagesRemaining: data['freeMessagesRemaining'] ?? 0,
      followers: data['followers'] ?? 0,
      liveEnabled: data['liveEnabled'] ?? false,
      coinBalance: data['coinBalance'] ?? 0,
      photoUrl: data['photoUrl'],
      bio: data['bio'] ?? '',
      socialLinks: data['socialLinks'] != null
          ? Map<String, String>.from(data['socialLinks'])
          : const {},
      username: data['username'] ?? '',
      firstName: data['firstName'] ?? '',
      lastName: data['lastName'] ?? '',
      dateOfBirth: data['dateOfBirth'],
      phoneNumber: data['phoneNumber'],
      twoStepEnabled: data['twoStepEnabled'] ?? false,
    );
  }

  /// Referral count needed to reach the next level, for progress display.
  static const List<Map<String, dynamic>> levelThresholds = [
    {'count': 10, 'name': 'Bronze'},
    {'count': 20, 'name': 'Silver'},
    {'count': 50, 'name': 'Diamond'},
    {'count': 100, 'name': 'Platinum'},
    {'count': 500, 'name': 'Platinum 1'},
    {'count': 1000, 'name': 'Platinum 2'},
    {'count': 5000, 'name': 'Gold'},
    {'count': 10000, 'name': 'Gold Plus'},
  ];
}
