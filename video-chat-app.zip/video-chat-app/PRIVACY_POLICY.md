# Privacy Policy

**App Name:** [Your App Name]
**Location:** Lahore, Pakistan
**Last Updated:** [Insert Date]

## 1. Introduction
This Privacy Policy explains how [Your App Name] ("we", "our", "us"), based in Lahore, Pakistan, collects, uses, and protects information when you use our video chatting and social application.

## 2. Information We Collect
- **Account information:** name, email address, phone number, or Google account details used to sign up.
- **Profile content:** videos, photos, comments, and messages you post.
- **Usage data:** app interactions, referral activity, likes, follows, and watch history.
- **Device information:** device type, operating system, and IP address, for security and performance.
- **Payment information:** if you purchase coins/in-app items, payment is processed by a third-party licensed payment provider; we do not store your card details.

## 3. How We Use Information
- To provide and operate video chat, live streaming, and social features.
- To manage the referral and reward system (in-app free messages and level badges only).
- To personalize content, such as music suggestions.
- To ensure safety, prevent abuse, and enforce our Terms of Service.
- To communicate updates, security alerts, and support responses.

## 4. Sharing of Information
We do not sell your personal data. We may share information with:
- Service providers (e.g. cloud hosting, payment processors) strictly to operate the app.
- Law enforcement, if required by applicable law in Pakistan or other relevant jurisdictions.

## 5. Live Streaming & Public Content
Videos, comments, and live streams you post are visible to other users. Please avoid sharing sensitive personal information publicly.

## 6. Data Security
We use industry-standard measures (encryption in transit, access controls) to protect your data. No system is 100% secure, and we encourage strong, unique passwords.

## 7. Children's Privacy
This app is not intended for users under 13 (or the minimum age required by local law). We do not knowingly collect data from children below this age.

## 8. Your Rights
You may request to access, correct, or delete your account data by contacting us at [support email]. You can delete your account at any time from Settings.

## 9. Referral & Rewards Disclaimer
Referral rewards (free messages, badges/levels) are in-app benefits only. They have no cash value and cannot be exchanged, transferred, or withdrawn as money.

## 10. Changes to This Policy
We may update this Privacy Policy from time to time. Continued use of the app after changes constitutes acceptance of the updated policy.

## 11. Contact Us
[Your App Name]
Lahore, Pakistan
Email: [support email]
