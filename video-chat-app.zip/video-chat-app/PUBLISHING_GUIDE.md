# Publishing Guide — Getting Vibby Live

This is the exact order of steps to take the project from "code in a zip"
to "real app people can install." Follow top to bottom — later steps
depend on earlier ones. Everything here can be done from a phone browser
using GitHub Codespaces (a free cloud computer), since a Windows/Mac
computer isn't available.

**Rough time:** a focused afternoon for Phase 1–4 (backend live, APK
built). Play Store review (Phase 6) adds its own multi-day wait on top —
that part is out of your hands once submitted.

---

## Phase 1 — Get the code onto GitHub

1. Create a free account at [github.com](https://github.com).
2. Create a new repository (e.g. `vibby-app`) — keep it **private** for
   now (it will have API keys referenced in it later).
3. On the repo page: **Add file → Upload files**, then upload the
   contents of the `video-chat-app.zip` you already have (extract it
   first — GitHub won't unzip for you). Commit.

## Phase 2 — Open a cloud computer (Codespaces)

1. On the repo page, click the green **Code** button → **Codespaces**
   tab → **Create codespace on main**.
2. This opens a full Linux machine + VS Code in your browser — works on
   a phone, though a tablet or borrowed laptop screen will be much less
   painful for the next steps.
3. In the Codespaces terminal, install Flutter:
   ```
   git clone https://github.com/flutter/flutter.git -b stable --depth 1
   echo 'export PATH="$PATH:$PWD/flutter/bin"' >> ~/.bashrc
   source ~/.bashrc
   flutter doctor
   ```
4. Install the Firebase CLI and Node dependencies:
   ```
   npm install -g firebase-tools
   ```

## Phase 3 — Set up Firebase (the backend's home)

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
   (works fine on a phone browser) and create a new project.
2. In the project: enable **Authentication** (turn on Email/Password,
   Phone, and Google sign-in methods), and create a **Firestore
   Database** (start in production mode) and **Storage** bucket.
3. Back in Codespaces terminal:
   ```
   firebase login --no-localhost
   ```
   This prints a URL — open it on your phone, approve, copy the code
   back into the terminal.
4. ```
   cd backend
   firebase use --add
   ```
   Pick the Firebase project you just created.
5. Set your API keys (only add the ones you actually have — every
   feature that needs one degrades gracefully without it, per the
   README):
   ```
   firebase functions:config:set stripe.secret="sk_test_..." stripe.webhook_secret="whsec_..."
   firebase functions:config:set cricket.api_key="..."
   firebase functions:config:set news.api_key="..."
   firebase functions:config:set amazon.access_key="..." amazon.secret_key="..." amazon.partner_tag="..."
   ```
6. Deploy the backend:
   ```
   cd functions && npm install && cd ..
   firebase deploy --only functions,firestore:rules
   ```
   This is the moment the backend goes **live** — Cloud Functions and
   security rules are now running on Google's servers.

## Phase 4 — Connect the Flutter app to Firebase

1. ```
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   Pick the same Firebase project. This generates
   `frontend/lib/firebase_options.dart` automatically.
2. In `frontend/lib/main.dart`, replace `pk_test_REPLACE_WITH_YOUR_KEY`
   with your real Stripe **publishable** key.
3. In `frontend/lib/screens/amazon_screen.dart`, replace
   `AMAZON_CLIENT_ID` if you're using the Amazon login feature.
4. ```
   cd frontend
   flutter pub get
   ```

## Phase 5 — Build the APK

```
flutter build apk --release
```

The finished file is at
`frontend/build/app/outputs/flutter-apk/app-release.apk`. In
Codespaces, right-click it in the file explorer → **Download** to get
it onto your phone.

**This APK is a real, installable app right now** — you can share it
directly (via Google Drive, WhatsApp, or the landing page's download
button) without waiting on any store review. On a phone, installing it
requires enabling "Install unknown apps" for whichever app you send it
through (Settings → Apps → Special access).

> **Signing note:** the command above produces a debug-signed APK, fine
> for testing and direct sharing. For the Play Store (Phase 6) you'll
> need a proper release keystore — Flutter's official guide covers this:
> [docs.flutter.dev/deployment/android](https://docs.flutter.dev/deployment/android)

## Phase 6 — (Optional, later) Publish to Google Play Store

This is a separate, slower track — do it once the app is stable and
tested via direct APK sharing:

1. Pay the one-time **$25 USD** Google Play Developer registration fee
   at [play.google.com/console](https://play.google.com/console).
2. Build a signed **App Bundle** (Play Store prefers this over APK):
   `flutter build appbundle --release` (after setting up the release
   keystore from the note above).
3. Fill in the store listing: description, screenshots (use the mockups
   we generated, or real screen recordings), privacy policy URL (your
   hosted `privacy-policy.html`), and a content rating questionnaire.
4. Submit for review. Google's review typically takes a few days to a
   couple of weeks for a first submission, sometimes longer if the app
   involves payments, live streaming, or chat (all of which this app
   has) — expect follow-up questions about content moderation and safety
   features.

## Phase 7 — Host the landing page

1. From the `backend` folder in Codespaces:
   ```
   firebase init hosting
   ```
   Point it at a new folder containing `index.html` and
   `privacy-policy.html` (copy them in first).
2. ```
   firebase deploy --only hosting
   ```
3. You'll get a real URL like `vibby-app.web.app` — this is what goes
   in the landing page's "Copy link" / "Share" buttons, and what you
   send people right now to get the APK.

---

## What's genuinely live after Phase 3 vs. what still needs your accounts

| Live after following this guide | Needs your own account/approval first |
|---|---|
| Sign-up/login, referrals, chat, groups, video feed, live rooms, posts, Namaz timings | Card payments (needs a real Stripe account) |
| Coin balance, boost requests, monetization tracking | Amazon product search (needs Associates approval) |
| Landing page + privacy policy, hosted for real | Live cricket / news (needs a free API key each) |
| | Telenor bundles actually loading onto a phone (needs a reseller/aggregator deal) |
| | Play Store listing (needs the $25 fee + review) |

Everything in the left column works the moment Phase 3–5 are done —
right column items are each documented with exact setup steps in
`README.md` inside the project, for whenever you're ready to pursue them.
